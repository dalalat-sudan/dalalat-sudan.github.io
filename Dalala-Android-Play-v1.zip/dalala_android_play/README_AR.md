# تطبيق دلالة العربات والعقارات — نسخة Google Play

هذه النسخة تفتح الموقع الرسمي:
https://dalalat-sudan.github.io/

## الإعدادات
- Package: `com.dalalatsudan.market`
- Version: `1.0.0` (versionCode 1)
- minSdk: 24
- targetSdk / compileSdk: 36 (Android 16)
- يدعم رفع الصور والفيديو من الهاتف.
- يفتح واتساب والاتصال والبريد والروابط الخارجية في التطبيقات المناسبة.
- يعالج مساحة شريط الحالة والتنقل في Android حتى لا تغطي أزرار الموقع.
- شاشة إعادة محاولة عند تعذر الاتصال.

## البناء
Workflow موجود في:
`.github/workflows/android-build.yml`

يبني APK للتجربة وAAB للإصدار. ملف AAB النهائي المرفوع إلى Google Play يجب توقيعه بمفتاح رفع محفوظ لدى صاحب التطبيق.
