طريقة الرفع على Cloudflare:
1) فك الضغط غير مطلوب إذا كانت صفحة Cloudflare تقبل ZIP.
2) ارفع ملف dalala_free_site.zip في مربع Drop a folder, or a zip.
3) انتظر اكتمال النشر.
4) سيظهر لك رابط مجاني للموقع.
