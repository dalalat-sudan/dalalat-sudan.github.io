# Android Java Auth API — باقتك

تاريخ التحديث والتحقق: 24 أكتوبر 2026. هذه نسخة مكتملة ومراجعة من التقرير السابق؛ لا تلغي حدود الاختبار الموضّحة أدناه. نطاق العمل: الحسابات فقط؛ نفس Lovable Cloud والحسابات وOTP والبريد الحالي. التقرير موجّه إلى مطوّر Java داخل CodeAssist.

## 1. حالة التنفيذ والنشر

**تم تنفيذ ستة مسارات HTTP ثابتة**، وإعادة استخدام الإجراءات نفسها التي يستدعيها الموقع؛ إعادة إرسال رمز الاستعادة تستخدم مسار الطلب نفسه. لا يعتمد Android على `/_serverFn/` ولا على طريقة تسلسل TanStack الداخلية.

**لم تُنشر التغييرات على الموقع العام.** اختبار `POST https://baqtak.com/api/public/auth/v1/signup/start` أعاد `404` وHTML، وليس عقد JSON الجديد. يجب نشر المشروع من Lovable ثم إعادة اختبار الروابط الستة على النطاق العام. لا تُحوّل التطبيق للإنتاج قبل ذلك. الاختبارات التنفيذية أدناه تمت على الموقع الجاري محليًا والمتصل بقاعدة المشروع الحالية، وليس نسخة Android فعلية.

لم تُنشأ قاعدة جديدة، ولم تُغيّر RLS أو الجداول أو إعدادات Authentication. أُنشئ حساب اختبار معزول ثم حُذف هو وبيانات الاختبار التابعة له. لم تُعدّل حسابات المستخدمين الحقيقيين. إصدار OTP يضع الرسالة في الطابور الحقيقي الموجود؛ نجاح الاستدعاء لا يعني ضمان وصول الرسالة لصندوق البريد.

**قيد مهم قبل توسيع تطبيق الهاتف:** منع العمليات لكل الحسابات المحظورة ليس شاملاً على الخادم في التنفيذ الحالي؛ تفاصيل مثبتة في القسم 7. لم يُصلح هذا التقرير تلك السياسات، ولا يصح الادعاء أن تطبيق Java سيكون محميًا بمجرد إخفاء الأزرار.

## 2. عناوين الربط والمفتاح العام

- أصل مسارات الحسابات الجديد: `https://baqtak.com/api/public/auth/v1`.
- `BACKEND_URL` و`PUBLIC_API_KEY`: استخدم عنوان Lovable Cloud وقيمة مفتاح **anon العام** الواردين في القسم الأول من `baqtak-flutterflow-api-report.md` الموجود لديك. جرى التحقق من عمل اتصال هذا المشروع عبر تسجيل الدخول وRPC في الاختبارات. القيم نفسها ليست مفتاح حساب المستخدم ولا مفتاح الخادم؛ لا أُعيد نشر عنوان الخدمة الداخلي هنا.
- مفتاح anon/publishable يجوز تضمينه في Android؛ ليس سرًا يمنح تجاوز RLS. **لا تضمّن service_role أو أي سر خادم**.
- اختبارات اليوم أثبتت عمل مفتاح الاتصال العام المهيأ للمشروع مع login وrefresh وRPC. لم يُدرج أي سر خادم في التقرير. لا تفترض صلاحية نسخة قديمة من المفتاح بعد تدويره؛ قيمة الاتصال العامة من إعداد اتصال مشروعك هي المرجع.
- المسارات الجديدة لا تحتاج `apikey` أصلًا. يحتاج اتصال Auth وRPC المباشر إلى `apikey: PUBLIC_API_KEY`.
- في الأمثلة، استبدل `BACKEND_URL` و`PUBLIC_API_KEY` بالقيم العامة من تقريرك؛ ليست قيمًا حرفية صالحة للاستخدام.

## 3. عقد HTTP العام للمسارات الجديدة

كل العمليات التالية `POST`، وترسل **JSON مباشرًا** وليس `{"data":{...}}`.

```http
Content-Type: application/json
Accept: application/json
```

لا تحتاج جلسة سابقة، ولا `Authorization: Bearer`، ولا Cookies، ولا CSRF token، ولا Origin header من تطبيق Java. هذه عمليات عامة مقصودة: إنشاء الحساب يتطلب OTP، وتغيير كلمة المرور يتطلب تذكرة مشتقة من OTP الصحيح. لا يُعتد بأي Cookies أو Bearer مرسل لإثبات امتلاك البريد في هذه المسارات.

- CORS: `Access-Control-Allow-Origin: *`، `POST, OPTIONS`، و`Content-Type, Accept`. لا تُستخدم CORS كحماية حسابات؛ Android لا يخضع لقيود CORS الخاصة بالمتصفح.
- `OPTIONS` يرجع `204`. يرسل Java الطلب POST مباشرة.
- كل الردود تحمل `Cache-Control: no-store`.
- حد الطلب: 8192 بايت. `413` عند تجاوز الحد؛ `415` عند غياب Content-Type الصحيح؛ `400` عند JSON غير صالح.
- لا Query Parameters ولا Path Parameters. البريد والرمز وكلمة المرور والتذكرة داخل body فقط، لا URL.
- الحقول غير المعرّفة تُحذف أثناء التحقق؛ إرسال بيانات موافقة الشروط لا يجعلها محفوظة.
- جميع نجاحات POST الجديدة `200`؛ لا يرجع أي مسار منها Access Token.
- اقرأ body حتى مع non-2xx؛ أحيانًا الخطأ يحتوي `message`، وأحيانًا `issues`، وليس دائمًا `error`.

أخطاء مشتركة فعلية:

```json
{"ok":false,"error":"invalid_json","message":"محتوى JSON غير صالح."}
```

```json
{"ok":false,"error":"validation_error","issues":[{"field":"firstName","message":"كل اسم يجب أن يكون حرفين على الأقل"}]}
```

```json
{"ok":false,"error":"unsupported_media_type","message":"يجب إرسال JSON."}
```

```json
{"ok":false,"error":"payload_too_large"}
```

```json
{"ok":false,"error":"server_error","message":"تعذّر إكمال العملية، يرجى المحاولة مرة أخرى."}
```

الأول والثاني `400`، الثالث `415`، الرابع `413`، الخامس `503`. النصوص الإنجليزية الافتراضية لبعض أخطاء Zod، مثل `Required`، ما زالت ممكنة. حوّل رسائلها إلى عرض عربي في Android دون كشف الطلب الخام.

### 3.1 بدء التسجيل

`POST https://baqtak.com/api/public/auth/v1/signup/start`

```json
{"email":"android.auth@example.com","password":"Example123!","firstName":"أحمد","secondName":"محمد","thirdName":"حسن"}
```

نجاح `200`:
```json
{"ok":true,"status":"otp_sent"}
```

البريد مسجل ومؤكد `409`:
```json
{"ok":false,"status":"email_taken","message":"هذا البريد الإلكتروني مسجل بالفعل، يرجى تسجيل الدخول."}
```

حساب إداري `403`:
```json
{"ok":false,"message":"هذا البريد يخص حساباً إداريًا، يرجى استخدام بريد آخر."}
```

فشل إرسال/وصول الخدمة `503`:
```json
{"ok":false,"message":"تعذّر إرسال رمز التحقق، يرجى المحاولة مرة أخرى."}
```

التحقق من الاسم والبريد وكلمة المرور يحدث قبل الإرسال. **لا يُنشأ حساب في هذه الخطوة**، ولا تُحفظ كلمة المرور أو الأسماء في صف OTP؛ يحتفظ Android بها في ذاكرة الشاشة مؤقتًا ليرسلها مع التحقق.

### 3.2 إعادة إرسال رمز التسجيل

`POST https://baqtak.com/api/public/auth/v1/signup/resend`

```json
{"email":"android.auth@example.com"}
```

نجاح `200`: `{"ok":true}`.

الحساب مؤكد `409`:
```json
{"ok":false,"status":"confirmed","message":"هذا الحساب مؤكد بالفعل، يمكنك تسجيل الدخول."}
```

أي رمز سابق غير مستخدم لنفس البريد والغرض يُلغى. أخطاء `403,429,503` كما في قواعد الإرسال. هذا المسار لا يستقبل أسماء أو كلمة مرور، ولا يُنشئ حسابًا.

### 3.3 التحقق من رمز التسجيل وإنشاء الحساب

`POST https://baqtak.com/api/public/auth/v1/signup/verify`

```json
{"email":"android.auth@example.com","password":"Example123!","firstName":"أحمد","secondName":"محمد","thirdName":"حسن","code":"123456"}
```

نجاح `200`: `{"ok":true}`. بعدها نفّذ تسجيل الدخول بالبريد وكلمة المرور؛ لا يتضمن النجاح user/session.

- الحساب مؤكد مسبقًا: `409 email_taken` كما أعلاه.
- رمز غير صحيح `400`:
```json
{"ok":false,"message":"رمز التحقق غير صحيح، يرجى المحاولة مرة أخرى."}
```
- منتهي/مستخدم/لا يوجد رمز `400`:
```json
{"ok":false,"message":"انتهت صلاحية رمز التحقق، يرجى طلب رمز جديد."}
```
- صيغة الرمز `400`:
```json
{"ok":false,"message":"يرجى إدخال الرمز المكوّن من 6 أرقام"}
```
- حد المحاولات `429`:
```json
{"ok":false,"message":"محاولات كثيرة، يرجى طلب رمز جديد."}
```
- فشل إنشاء الحساب `503`:
```json
{"ok":false,"message":"تعذّر إنشاء الحساب، يرجى المحاولة مرة أخرى."}
```

يُستهلك OTP أولاً، ثم ينشأ الحساب المؤكد أو يُعاد استخدام سجل قديم غير مؤكد. إذا فشل إنشاء الحساب بعد استهلاك الرمز، يجب طلب رمز جديد. التحقق الحالي يثبت البريد، وليس ربطًا مشفرًا للأسماء أو كلمة المرور المقدمة في start؛ بيانات verify هي التي تُستخدم للإنشاء.

### 3.4 طلب رمز الاستعادة وإعادة إرساله

`POST https://baqtak.com/api/public/auth/v1/password-reset/request`

```json
{"email":"android.auth@example.com"}
```

نجاح `200`: `{"ok":true,"status":"otp_sent"}`.

البريد غير مسجل `404`:
```json
{"ok":false,"status":"not_registered"}
```

حساب إداري `403`:
```json
{"ok":false,"message":"هذا البريد يخص حساب إداري، يرجى التواصل مع الإدارة لإعادة تعيين كلمة المرور."}
```

**استخدم المسار نفسه لإعادة الإرسال** بعد انقضاء مهلة الخادم؛ لا يوجد مسار resend مستقل للاستعادة. أخطاء `429,503` وقواعد الإلغاء نفسها.

### 3.5 التحقق من رمز الاستعادة وإصدار التذكرة

`POST https://baqtak.com/api/public/auth/v1/password-reset/verify`

```json
{"email":"android.auth@example.com","code":"123456"}
```

نجاح `200`، مثال منقح؛ القيمة الحقيقية سلسلة hex من 64 حرفًا:
```json
{"ok":true,"ticket":"<ONE_TIME_RESET_TICKET>"}
```

البريد غير موجود `400`:
```json
{"ok":false,"message":"لا يوجد حساب بهذا البريد الإلكتروني."}
```

رمز غير صحيح أو منتهي `400`، حد محاولات `429` كما في verify التسجيل. يُستهلك OTP وتصدر تذكرة، ويُلغى أي reset ticket سابق غير مستخدم لنفس البريد. لا يُصدر هذا المسار session أو access_token.

### 3.6 إكمال إعادة تعيين كلمة المرور

`POST https://baqtak.com/api/public/auth/v1/password-reset/complete`

```json
{"email":"android.auth@example.com","ticket":"<ONE_TIME_RESET_TICKET>","password":"NewExample456!"}
```

نجاح `200`: `{"ok":true}`. نفّذ تسجيل الدخول بكلمة المرور الجديدة، ثم تسلسل الحساب أدناه.

تذكرة غير صحيحة/منتهية/مستخدمة `400`:
```json
{"ok":false,"message":"انتهت صلاحية عملية إعادة التعيين، يرجى طلب رمز جديد."}
```

كلمة مرور ضعيفة `400`، أمثلة:
```json
{"ok":false,"message":"كلمة المرور يجب أن تكون 8 خانات على الأقل."}
```
```json
{"ok":false,"message":"يرجى إضافة رقم واحد على الأقل إلى كلمة المرور."}
```

كلمة جديدة مطابقة للقديمة `400` إن رفضتها خدمة Auth:
```json
{"ok":false,"message":"كلمة المرور الجديدة مطابقة للقديمة، يرجى اختيار كلمة مرور مختلفة."}
```

فشل الخدمة `503`:
```json
{"ok":false,"message":"تعذّر تحديث كلمة المرور، يرجى المحاولة مرة أخرى."}
```

التحقق من كلمة المرور يسبق لمس التذكرة. لا تُستهلك التذكرة عند رفض كلمة المرور؛ تُستهلك بعد نجاح تحديث Auth. احتفظ بالتذكرة في الذاكرة المؤقتة فقط، وامسحها بعد النجاح/الانتهاء. لا يُنفذ المسار تصريحًا إضافيًا عبر Cookies.

## 4. الصلاحية والحدود الفعلية — لا تعتمد على التقرير السابق

| القاعدة | التنفيذ الحالي |
|---|---|
| OTP | 6 أرقام ASCII، يُولَّد على الخادم ويُخزَّن SHA-256 |
| عمر OTP | 300 ثانية = 5 دقائق |
| مهلة إعادة الإرسال | **60 ثانية**، وليس 300 ثانية |
| الحد الساعي | 6 إصدارات لكل بريد ولكل purpose خلال ساعة متحركة |
| المحاولات | 5 محاولات خاطئة؛ التالية تُحرق الرمز وتُرفض؛ الناجح بعد وصول العداد إلى 5 مرفوض |
| إلغاء السابق | إصدار جديد يلغي كل الرموز غير المستخدمة لنفس البريد والغرض |
| عمر reset ticket | **10 دقائق فعليًا** (`TICKET_TTL_MINUTES=10`)، وليس 5 كما ذُكر سابقًا |
| التذكرة | 32 بايت عشوائية في hex = 64 حرفًا؛ تخزين SHA-256 وربط user_id بالبريد |
| الاستخدام | إلغاء/استهلاك بعد النجاح، وعدم تخزين الرمز في عنوان URL أو Android logs |

تم الإبقاء على عمر التذكرة الفعلي ولم يُغيّر لأن الطلب الحالي طلب توثيقًا لمنطق الموقع وليس تحديد عمر جديد.

**حدود مهمة:** rate limiting الحالي بحسب البريد والغرض، وليس IP أو جهاز؛ فحص الحدود وتحديث المحاولات والاستهلاك عمليات متعددة وليست معاملة ذرية. لا يُضمن منع التجاوز أو إعادة الاستخدام عند الطلبات المتزامنة؛ لا ترسل طلبات verify/complete متوازية من التطبيق، وعطّل الإرسال أثناء الطلب. هذا إجراء UI لا يعوّض الإصلاح الذري على الخادم. لم تُختبر هجمات التزامن. نجاح `otp_sent` يعني إدخال الرسالة في الطابور، وليس تأكيد تسليمها. محاولة إرسال فاشلة بعد إنشاء صف OTP قد تحتسب ضمن الحدود.

مرسل البريد الموجود: منصة باقتك، باستخدام طابور transactional الحالي. لم تُغيّر خدمة البريد.

## 5. تسجيل الدخول والجلسة في Java

تسجيل الدخول موجود في خدمة Auth الحالية؛ لم يُنشأ له proxy جديد:

```http
POST BACKEND_URL/auth/v1/token?grant_type=password
apikey: PUBLIC_API_KEY
Content-Type: application/json
```
```json
{"email":"android.auth@example.com","password":"Example123!"}
```

نجاح معتاد `200`، مثال منقح وليس dump حرفيًا لكل الحقول التي قد ترجعها الخدمة:
```json
{"access_token":"<ACCESS_TOKEN>","token_type":"bearer","expires_in":3600,"refresh_token":"<REFRESH_TOKEN>","user":{"id":"<USER_UUID>","email":"android.auth@example.com"}}
```

قد ترجع الخدمة أيضًا `expires_at` وحقول user/identities إضافية؛ استخدم الاستجابة الحقيقية لا افتراض عدد ثابت من الحقول. كلمة المرور الخاطئة عادة `400` مع `error_code: invalid_credentials` ورسالة `Invalid login credentials`؛ إعدادات وأخطاء الخدمة قد تغيّر الشكل. لم تُختبر كل أخطاء Auth المستضافة.

**ما يُحفظ بعد الدخول:** access_token، refresh_token، token_type، وقت انتهاء الوصول محسوبًا من expires_in أو expires_at، وuser.id. تُخزَّن الرموز في تخزين مشفر مدعوم Android Keystore؛ ليس SharedPreferences عاديًا، ولا Logcat، ولا ملفات عامة. لا تُحفظ كلمة المرور أو OTP. أسماء المستخدم والعرض ليست مصدر صلاحيات.

تجديد الجلسة:
```http
POST BACKEND_URL/auth/v1/token?grant_type=refresh_token
apikey: PUBLIC_API_KEY
Content-Type: application/json
```
```json
{"refresh_token":"<REFRESH_TOKEN>"}
```

استبدل **كلا الرمزين** من الاستجابة الجديدة واحفظ انتهاء الوصول. امنع refresh المتزامن المتعدد. عند فشل refresh، امسح session واعرض الدخول. نجح اختبار refresh `200`.

الخروج:
```http
POST BACKEND_URL/auth/v1/logout
apikey: PUBLIC_API_KEY
Authorization: Bearer <ACCESS_TOKEN>
```

نجح الاختبار `204` بلا JSON. امسح بيانات التطبيق المحمية والرموز محليًا حتى عند تعذر الاتصال، ولا تسمح بالرجوع لشاشة الحساب من سجل التنقل. النطاق الافتراضي لخدمة logout قد يؤثر على جلسات الحساب الأخرى؛ إذا أردت الخروج من هذا الجهاز فقط استخدم `?scope=local`، لكن هذا الخيار لم يُختبر في هذه المهمة.

للتحقق من session محفوظة:
```http
GET BACKEND_URL/auth/v1/user
apikey: PUBLIC_API_KEY
Authorization: Bearer <ACCESS_TOKEN>
```

ثم نفّذ فحوص الحساب؛ لا تعتبر وجود رمز محفوظ نجاح مصادقة. لا تعتمد على Cookies للعميل الأصلي.

## 6. التسلسل الصحيح بعد أي دخول أو استعادة session

للتطبيق العادي، تسلسل موصى به مشتق من الوظائف الفعلية:

1. تسجيل الدخول واستلام user.id وsession.
2. `is_staff_user()`؛ إذا true لا تفتح التطبيق العادي، وامسح الجلسة أو سجّل الخروج.
3. `ensure_my_profile()`؛ لا تكمل إذا كان `ok=false` أو فشل الاتصال.
4. `auto_unban_expired()` قبل قراءة الحظر؛ يفك الحظر المؤقت المنتهي، وليس كل الحظر الجزئي المنتهي.
5. `get_ban_status({_user_id: user.id})`؛ امنع الدخول عند permanent/temporary، أو partial مع scope `login`، وامنع أقسام partial حسب scopes.

كرر فحص الحظر عند استعادة الاتصال/العودة للتطبيق؛ لا تعتبر خطأ الشبكة `is_banned=false`. الموقع الحالي موزّع بين login وAuthProvider وBanProvider، وليس سلسلة واحدة متزامنة. Android يجب ألا يكرر سلوك fail-open الحالي.

كل RPC التالية `POST BACKEND_URL/rest/v1/rpc/<name>`، وbody مباشر.

```http
apikey: PUBLIC_API_KEY
Authorization: Bearer <ACCESS_TOKEN>
Content-Type: application/json
Accept: application/json
```

### is_staff_user
- Endpoint: `BACKEND_URL/rest/v1/rpc/is_staff_user`
- Body `{}`، بلا وسائط.
- SQL boolean؛ نجاح `200` مع **`false` أو `true` مباشرةً**، وليس `{staff:false}`.
- مشتق من `auth.uid()` وجدول staff_accounts.
- grants الحالية: anon وauthenticated وservice_role. غير المسجل يرجع false؛ هذا ليس إثباتًا للمصادقة.
- الاختيار الأنسب لفحص المستخدم الحالي. تم اختباره false بحساب الاختبار.

### is_staff_account
- Endpoint: `BACKEND_URL/rest/v1/rpc/is_staff_account`
- Body `{"_user_id":"<USER_UUID>"}`؛ UUID مطلوب.
- نجاح `200` مع boolean مباشرة.
- grants: anon وauthenticated وservice_role.
- لا تحتاج استدعاء الدالتين؛ استخدم is_staff_user لتقليل التعامل مع user ID.
- الدالة تقبل UUID آخر ولا تربطه بالمستدعي؛ لا تبنِ عليها كشف حسابات الآخرين. لم تُستدع في اختبار الحساب.

### ensure_my_profile
- Endpoint: `BACKEND_URL/rest/v1/rpc/ensure_my_profile`
- Body `{}`؛ تستخرج هوية المستخدم من auth.uid.
- grants: authenticated وservice_role؛ لا anon.
- نجاح `200`، مثال شكل كامل لمستخدم:
```json
{"ok":true,"created":false,"account_number":"<SIX_DIGIT_ACCOUNT_NUMBER>","full_name":"اختبار حساب باقتك"}
```
- created يدل على إدخال صف profile أثناء الاستدعاء، وليس إنشاء auth user. اختبارنا رجع false لأن profile كان موجودًا بالفعل.
- staff: `{"ok":true,"staff":true}`، بلا إنشاء profile.
- فشل منطقي: `{"ok":false,"reason":"not_authenticated"}` أو `{"ok":false,"reason":"no_auth_user"}`؛ يجب فحص ok وليس status فقط.
- تنشئ profile عند الحاجة، وتملأ البيانات الناقصة، وتضيف دور user عند الحاجة؛ لا تُرسل user_id ولا balance ولا role من Java.

### auto_unban_expired
- Endpoint: `BACKEND_URL/rest/v1/rpc/auto_unban_expired`
- Body `{}`، returns void.
- grants: authenticated وservice_role.
- الاختبار رجع **204 بلا body**، وليس `{ok:true}`.
- SQL الحالي يحدّث كل profiles ذات status=banned وban_type=temporary وban_expires_at<=now، لا مستخدم المستدعي فقط؛ إذن وظيفته عامة لمعالجة انتهاء الحظر وليست قراءة.
- يعيد status=active ويصفّر حقول الحظر. لا ترسل أي وسائط.

### get_ban_status
- Endpoint: `BACKEND_URL/rest/v1/rpc/get_ban_status`
- Body `{"_user_id":"<USER_UUID_FROM_SESSION>"}`.
- grants: authenticated وservice_role.
- returns TABLE؛ لذلك JSON **مصفوفة من صف واحد**، وليس object.
- نجاح حساب غير محظور `200`، اختُبر:
```json
[{"is_banned":false,"ban_type":null,"reason":null,"expires_at":null,"scopes":[]}]
```
- مثال اصطناعي مطابق للأعمدة لحساب محظور، لم يُطبّق على حساب حقيقي:
```json
[{"is_banned":true,"ban_type":"partial","reason":"سبب إداري","expires_at":null,"scopes":["login"]}]
```
- الحساب غير الموجود أو غير banned، أو temporary المنتهي، يرجع الصف غير المحظور نفسه.
- **لا تتحقق الدالة الحالية أن _user_id=auth.uid()**؛ يقدر المستخدم المصادق على طلب حالة UUID آخر. خصوصية الحظر تحتاج تضييقًا لاحقًا؛ Java يرسل ID الجلسة فقط.

أخطاء REST/RPC تأتي عادة بشكل PostgREST:
```json
{"code":"42501","details":null,"hint":null,"message":"permission denied for function ensure_my_profile"}
```

بدون جلسة/مع رمز غير صالح قد ترى `401`، ومع صلاحيات غير كافية `403`، ومع UUID غير صالح `400`. لا تعمم أخطاء المسارات الجديدة العربية على RPC؛ لكل طبقة شكل مستقل. أمثلة الفشل هذه متوقعة من طبقة الخدمة ولم تُختبر كلها.

## 7. هل الحظر مطبّق على الخادم؟

**الإجابة الدقيقة: جزئيًا، وليس كقاعدة شاملة.**

- `execute_p2p_transfer` يفحص حالة المرسل والمستقبل active ويُرجع أخطاء `sender_inactive/receiver_inactive`؛ فهذا منع خادم حقيقي لهذه العملية.
- `subscribe_to_audio_package` و`subscribe_to_card_package` و`subscribe_to_ebook_package` تفحص active وترفض `account_inactive`.
- تعريفات `place_wallet_order` و`purchase_guide` و`purchase_ebook` و`purchase_bundle` الحالية لا تتضمن فحص ban/status active. دوال SECURITY DEFINER لا يجوز افتراض أنها محمية بمنع واجهة الموقع أو RLS على صفوف القراءة.
- سياسة INSERT للطلبات تعتمد على `auth.uid()=user_id` ولا تتضمن حظرًا. سياسة INSERT لشحن الرصيد تتحقق من المالك، pending، amount>0، admin_note NULL؛ لا تتضمن شرط الحساب غير المحظور.
- حماية حقول profile تمنع المستخدم العادي من تغيير status/ban/balance؛ هذا يمنع إزالة الحظر ذاتيًا، لكنه لا يمنع كل عملية مالية أثناء الحظر.
- الموقع يرفض الدخول بعد حصوله على session بواسطة checkUserBanned وواجهة الحظر؛ عند فشل check يوجد مسار يسمح بالاستمرار، ولا يمنع ذلك الحصول على token مباشرة من Auth.
- لم تُضف في هذه المرحلة migration لمنع العمليات أو تعديل grants؛ هذا عمل أمني منفصل مطلوب **قبل ربط المحفظة والمشتريات**. لا يعتبر التطبيق الأصلي آمنًا إذا اعتمد على checkBan محلي فقط.

## 8. الأسماء وكلمة المرور

### thirdName

حقل الموقع نصه «الاسم الثالث / اسم العائلة» وautocomplete=family-name. إذن حقل **اسم العائلة في Android يُرسل `thirdName`**. لا ترسل `lastName`؛ العقد لا يعرفه. `secondName` ما زال مطلوبًا كحقل منفصل.

عند الإنشاء:
- firstName → user_metadata.first_name.
- secondName → user_metadata.second_name.
- thirdName → user_metadata.third_name، ثم profile.third_name عبر منطق إنشاء profile الحالي.
- full_name = الأسماء الثلاثة مفصولة بمسافة.
- لا يوجد mapping تلقائي إلى fourth_name ولا حقل family_name مستقل.

قواعد الخادم المشتركة بعد هذه المهمة: trim؛ طول كل اسم 2–50، يبدأ بحرف Unicode؛ بقية الاسم حروف أو whitespace أو `-` أو `'` أو `’`. أرقام/HTML/رموز أخرى مرفوضة. هذا هو نمط صفحة التسجيل نفسها، ورُفع إلى عقد مشترك حتى لا يتجاوز Android تحقق الواجهة.

البريد: trim/lowercase، صيغة بريد وطول <=254؛ بدء/تحقق التسجيل يطبّقان قائمة البريد المؤقت وقواعد validateEmail الحالية أيضًا. إعادة إرسال التسجيل والاستعادة تكتفي بصيغة البريد وطوله كما في المنطق السابق.

كلمة المرور: 8–20 خانة، رقم واحد على الأقل (ASCII أو أرقام عربية/فارسية)، وحرف أو رمز واحد على الأقل. لا trim لكلمة المرور. مثال `12345678` مرفوض، و`1234!@#$` مقبول. لا تعتبر الفراغ وحده رمزًا. Java String.length مثل فحص UTF-16 الحالي؛ لا تغيّر كلمة المستخدم بالتطبيع.

رسائل النقص:
- «كلمة المرور يجب أن تكون 8 خانات على الأقل.»
- «كلمة المرور يجب ألا تتجاوز 20 خانة.»
- «يرجى إضافة رقم واحد على الأقل إلى كلمة المرور.»
- «يرجى إضافة حرف أو رمز واحد على الأقل إلى كلمة المرور.»

تم تصحيح خلل فحص digits-only في checkPassword الموجود (كان يحذف أول رقم فقط ويعامل بقية الأرقام كرمز)، وتوحيد تحقق التسجيل بالخادم. لم يتغير تصميم الموقع. تأكيد كلمة المرور والتحقق من تطابق الحقلين يتمان محليًا؛ لا يرسل confirmPassword للخادم.

## 9. الشروط والموافقة

**لا تُسجَّل موافقة المستخدم أو إصدار الشروط أو تاريخها في التنفيذ الحالي الذي فُحص.** يوجد checkbox إلزامي في صفحة الموقع، لكن agreeTerms لا يدخل payload ولا user_metadata، ولا توجد أعمدة قبول شروط في schema الحالي التي فُحصت.

Android يعرض الشروط ويطلب موافقة محلية قبل المتابعة لمحاكاة الموقع، لكن هذا ليس سجل موافقة قابلًا للتدقيق. لا يوجد حقل supported مثل termsVersion/acceptedAt؛ إرسالها للمسارات الجديدة يُهمل، ولا يصح القول إنه سُجّل. لم تُنشأ API أو أعمدة جديدة لهذا الغرض.

## 10. أمثلة cURL منقحة

القيم التالية تعليمية فقط وليست حساب الاختبار المستخدم. لا تستخدم `-v` ولا تحفظ HTTP bodies التي تحمل credentials في سجلات CI. أنشئ متغيرات PASSWORD وOTP وRESET_TICKET محليًا من واجهة آمنة؛ لا تضع أسرار خادم فيها مطلقًا. أوامر jq تتطلب وجود jq على جهاز المطوّر، وليست مطلوبة لـJava.

```bash
AUTH_BASE='https://baqtak.com/api/public/auth/v1'
EMAIL='android.auth@example.com'
# PASSWORD وOTP وRESET_TICKET قيم مؤقتة يوفرها اختبارك؛ لا تطبعها.

jq -n --arg email "$EMAIL" --arg password "$PASSWORD" \
  '{email:$email,password:$password,firstName:"أحمد",secondName:"محمد",thirdName:"حسن"}' \
| curl --silent --show-error "$AUTH_BASE/signup/start" \
  -H 'Content-Type: application/json' -H 'Accept: application/json' --data-binary @-

jq -n --arg email "$EMAIL" '{email:$email}' \
| curl --silent --show-error "$AUTH_BASE/signup/resend" \
  -H 'Content-Type: application/json' --data-binary @-

jq -n --arg email "$EMAIL" --arg password "$PASSWORD" --arg code "$OTP" \
  '{email:$email,password:$password,firstName:"أحمد",secondName:"محمد",thirdName:"حسن",code:$code}' \
| curl --silent --show-error "$AUTH_BASE/signup/verify" \
  -H 'Content-Type: application/json' --data-binary @-

jq -n --arg email "$EMAIL" '{email:$email}' \
| curl --silent --show-error "$AUTH_BASE/password-reset/request" \
  -H 'Content-Type: application/json' --data-binary @-

jq -n --arg email "$EMAIL" --arg code "$OTP" '{email:$email,code:$code}' \
| curl --silent --show-error "$AUTH_BASE/password-reset/verify" \
  -H 'Content-Type: application/json' --data-binary @-
# الرد يحتوي ticket: اقرأه في ذاكرة عميلك؛ لا تنشر الرد ولا تسجله.

jq -n --arg email "$EMAIL" --arg ticket "$RESET_TICKET" --arg password "$NEW_PASSWORD" \
  '{email:$email,ticket:$ticket,password:$password}' \
| curl --silent --show-error "$AUTH_BASE/password-reset/complete" \
  -H 'Content-Type: application/json' --data-binary @-
```

مثال RPC بعد الدخول، بقيم عامة/token منقح:
```bash
curl --silent --show-error "$BACKEND_URL/rest/v1/rpc/get_ban_status" \
  -H "apikey: $PUBLIC_API_KEY" \
  -H "Authorization: Bearer $ACCESS_TOKEN" \
  -H 'Content-Type: application/json' \
  --data '{"_user_id":"<USER_UUID_FROM_SESSION>"}'
```

في Java استخدم JSON object مباشر، OkHttp أو HttpsURLConnection، وافصل نجاح HTTP عن `ok`؛ بعض RPC ترجع boolean/array/204 وليس object. لا تُفعّل HttpLoggingInterceptor BODY في الإنتاج لمسارات الحسابات.

## 11. الاختبارات المنفذة وما لم يُختبر

### اختبارات فعلية ببيانات معزولة

- بدء التسجيل نجح `200`؛ تحقق service-only أن الحساب لم يوجد بعد إرسال الرمز.
- JSON داخل data رُفض `400`؛ كلمة مرور أرقام فقط رُفضت `400`.
- resend التسجيل المبكر رُفض `429`.
- رمز خاطئ رُفض `400`، ثم إنشاء الحساب بـOTP اختبار نجح `200`.
- الدخول الحقيقي بالبريد وكلمة المرور نجح `200`، وجُلبت session دون طباعتها.
- is_staff_user=false `200`، ensure_my_profile `200`، get_ban_status لحساب الاختبار `200`. **لم أستدع auto_unban_expired في اختبار اليوم** لأنها تعدّل حالات جميع الحسابات ذات الحظر المؤقت المنتهي؛ تأكد شكل void وصلاحياتها من تعريف قاعدة البيانات فقط. نتيجة 204 المذكورة في النسخة السابقة ليست إعادة اختبار اليوم.
- بدء التسجيل للبريد المؤكد رُفض `409`.
- طلب reset نجح `200`، إعادة الطلب المبكر `429`، الرمز الخاطئ `400`.
- verify reset نجح وأصدر ticket؛ تكرار OTP رُفض `400`.
- كلمة مرور قصيرة رُفضت دون استهلاك ticket؛ كلمة جديدة صحيحة نجحت؛ إعادة استخدام ticket رُفضت `400`.
- تسجيل الدخول بالكلمة الجديدة `200`، refresh `200`، logout `204`.
- حُذف auth user الاختباري وprofile/roles والبيانات التابعة الاختبارية وOTP/log rows الخاصة به. لم تُقرأ payloads طابور البريد لاستخراج رموز حقيقية.

**توضيح منهجية OTP:** اختُبر مسار البريد الحقيقي إلى مرحلة enqueue، لكن لم أمتلك صندوق بريد اختبار للقراءة. بعد ذلك استُبدل hash الرمز داخل صف OTP لحساب الاختبار وحده برمز عشوائي تجريبي عبر اتصال الخادم، ثم استُدعيت verify HTTP العادية. هذا يختبر الاستهلاك وإنشاء الحساب والتذكرة وتحديث Auth الحقيقي، لكنه **ليس اختبارًا كاملاً لوصول رسالة OTP إلى البريد وإدخال الرمز المستلم**. لا تُضف هذه الطريقة أو أي سر إداري إلى Android.

### اختبارات محلية معزولة دون قاعدة بيانات

نجحت 17 اختبارات محلية (3 ملفات اختبار) تغطي body المباشر، طول وصيغة الاسم، كلمة المرور 8–20/رقم/حرف أو رمز، mapping 429، عمر OTP 300 ثانية، cooldown 60 ثانية، 6 إصدارات/ساعة، 5 محاولات، عمر ticket الفعلي 10 دقائق، وانتهاء ticket، إضافة إلى غياب الحاجة لجلسة سابقة، no-store، رفض تغليف data، JSON التالف، نوع المحتوى، حد 8192 بايت، 429، تنقيح استثناءات الخادم، وOPTIONS 204.

### فحص الموقع

صفحة إنشاء الحساب `/signup` فتحت في المتصفح؛ ملء حقول الأسماء الثلاثة نجح، ولم تظهر page errors. تم فحص لقطة الصفحة وبقي شكلها الحالي. لا يُعد هذا تنفيذًا للتسجيل من UI إلى صندوق بريد فعلي.

### لم يُختبر أو ليس مكتملًا

- وصول OTP لصندوق بريد اختبار، وإعادة إرسال ناجحة بعد انتظار 60 ثانية.
- الإنتاج بعد النشر، وجهاز Android/CodeAssist/Keystore فعلي.
- حساب إداري أو حساب محظور حقيقي؛ لم تُغيّر حالتهما للاختبار.
- هجمات التزامن وحدود IP/device والحد الساعي عبر ساعة فعلية.
- رفض العمليات المحظورة شاملًا: غير موجود حاليًا، كما في القسم 7.
- تبديل الشبكة/انتهاء token على Android وlogout scope=local.
- مطابقة سلسلة المفتاح في التقرير الأقدم حرفيًا بالمفتاح الحالي؛ صلاحية المفتاح الحالي نفسه اختُبرت.
- حفظ سجل موافقة الشروط: غير مدعوم حاليًا.

## 12. الملفات والتنفيذ المرجعي

- `src/lib/auth-actions.server.ts`: الإجراءات المشتركة المستخرجة من otp.functions، تستخدم otp.server والبريد نفسه.
- `src/lib/otp.functions.ts`: نفس exports السابقة للموقع، تغلف الإجراءات المشتركة.
- `src/lib/auth-contract.ts`: schemas المشتركة وHTTP status mapping.
- `src/lib/auth-http.ts`: JSON HTTP/CORS/no-store والأخطاء المنقحة.
- `src/routes/api/public/auth/v1/signup/{start,resend,verify}.ts`.
- `src/routes/api/public/auth/v1/password-reset/{request,verify,complete}.ts`.
- `src/lib/password-policy.ts`: تصحيح حذف كل الأرقام قبل فحص الرمز.
- اختبارات auth-contract وotp.server بجوار المنطق.

لا ترتبط Java بأي ملف أو function hash؛ تعتمد فقط الروابط HTTP الثابتة الموضحة. إعادة تسمية ملفات أو routes مستقبلًا قرار breaking API يجب تجنبه داخل v1.

**القرار العملي:** ربط شاشات الحسابات ممكن بعد نشر هذه المسارات والتحقق من البريد على حساب اختبار يملكه المطوّر. لا تبدأ ربط المحفظة والمشتريات قبل معالجة منع العمليات المحظورة على الخادم. لا يوجد نشر تلقائي ضمن هذه المهمة.


## 13. إكمال المهمة — نتيجة تحقق 24 أكتوبر 2026

### ما أُكمل الآن

- الروابط الستة موجودة وتستجيب محليًا بعقد JSON، باستخدام نفس إجراءات الموقع وOTP وطابور البريد؛ لم أضف مسارات بديلة أو حسابات منفصلة.
- عولج خطأ أنواع شاشة الخطأ العامة الذي كان يمنع فحص المعاينة، دون تغيير تصميمها أو سلوكها.
- أُضيفت اختبارات حد HTTP في `src/lib/auth-http.test.ts`؛ أصبح الإجمالي 17 اختبارًا ناجحًا.
- نُفّذت 31 عملية تحقق HTTP باستخدام بريد اختبار عشوائي منفصل: عقد الإدخال وOPTIONS لجميع المسارات، بدء التسجيل دون إنشاء الحساب، cooldown، التحقق، الدخول، RPC الخاصة بالحساب، تعارض البريد المسجل، استعادة كلمة المرور، رفض replay للرمز والتذكرة، رفض كلمة ضعيفة ثم قبول كلمة صحيحة، الدخول الجديد وrefresh والخروج المحلي.
- حُذف حساب الاختبار وصف profile ودوره ورموز OTP وسجلات البريد وunsubscribe المرتبطة به فقط. رسائل الاختبار التي أُدرجت في طابور البريد تعامل معها المرسل الحالي كالمعتاد؛ لم أقرأ أو أعدّل محتوى الطابور العام.
- لم أستدع الوظيفة العامة auto_unban_expired أثناء التحقق الجديد، لتجنب أي تعديل على حسابات المستخدمين الحقيقيين.
- فُتحت صفحة التسجيل الحالية في المتصفح ولم تُرصد أخطاء JavaScript؛ هذا فحص عدم تعطل الصفحة وليس اختبار تسليم OTP لصندوق البريد.

### تصحيح حدود التحقق

اختبار التسجيل والاستعادة نجح عبر مسارات HTTP الحقيقية إلى قاعدة المشروع، لكن الرمز المستخدم في verify كان رمز اختبار عشوائيًا: استُبدلت بصمته في صف حساب الاختبار وحده. لم أقرأ بريد أي مستخدم أو رمزًا فعليًا من الطابور. لذلك تحقق إرسال الطلب إلى طابور البريد، ولم يتحقق تسليم الرسالة وإدخال الرمز المستلم من صندوق بريد مملوك للمختبر. يلزم إجراء تلك الخطوة بعد النشر، وليس توفير كلمة مرور بريد أو سر خادم داخل التطبيق.

### حالة النشر الحالية

`POST https://baqtak.com/api/public/auth/v1/signup/start` ببيانات ناقصة عاد **404 مع HTML** يوم 24 أكتوبر 2026، بينما نفس الطلب في المعاينة المحلية عاد **400 مع validation_error JSON**. النتيجة: **المسارات جاهزة محليًا ولكنها غير منشورة بعد على baqtak.com وتحتاج نشر المشروع**. لم يُنفّذ نشر في هذه المهمة.

بعد النشر، اختبر `{}` على جميع المسارات للتأكد من 400 JSON وOPTIONS 204، ثم سجّل حساب اختبار ببريد تملكه وأكمل التسجيل والاستعادة بالرمز المستلم فعليًا. لا تنقل Android إلى الإنتاج قبل هذا التحقق. التطبيق Java نفسه وCodeAssist وKeystore لم تُختبر هنا، ولا يوجد مصدر Android داخل هذا المشروع.

### نقاط لم تُغيّر عمدًا

- لا تغيير للجداول أو RLS أو إعدادات Auth أو رموز VAPID أو Service Worker أو ملفات Android.
- سجل موافقة الشروط غير مدعوم على الخادم؛ لا تعتبر إرسال حقول إضافية حفظًا للموافقة.
- منع العمليات للمحظورين ليس شاملاً على الخادم، كما ثبت في القسم 7؛ **هذا قيد أمني غير محلول، وليس نجاحًا في شرط الحظر**. لا توسّع الربط للمحفظة أو المشتريات قبل إصلاحه واختباره في مهمة أمنية منفصلة.
- إصدار/استهلاك OTP والتذكرة ليس ذريًا؛ لم يُنفّذ اختبار طلبات متزامنة ولم تُضف معاملة قاعدة جديدة.
- عمر التذكرة الفعلي 10 دقائق كما في الكود الحالي؛ هذا يكشف اختلافًا عن مطلب الخمس دقائق السابق ولا يعني أنه عولج. لم أغيّره ضمن مهمة الحفاظ على منطق الموقع.
- فحص staff موجود في طلب الاستعادة، لكنه غير مكرر في verify/complete الحاليين؛ لا يوجد سيناريو نجاح مختبر لحساب إداري. التطبيق الحالي مخصص للمستخدم العادي.

### مثال الخروج من جهاز الاختبار فقط

```http
POST BACKEND_URL/auth/v1/logout?scope=local
apikey: PUBLIC_API_KEY
Authorization: Bearer <ACCESS_TOKEN>
```

يرجع 204 بلا body؛ هذا الخيار اختُبر اليوم. يمسح Java رموزه محليًا حتى لو تعذر الطلب. الخروج لا يبطل access token فورًا بالضرورة؛ قد يبقى صالحًا حتى انتهاء JWT، بينما refresh token يتوقف للجلسة الملغاة.
