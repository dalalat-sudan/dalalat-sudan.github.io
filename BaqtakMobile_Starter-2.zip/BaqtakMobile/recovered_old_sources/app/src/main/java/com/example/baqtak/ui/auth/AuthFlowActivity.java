package com.example.baqtak.ui.auth;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import com.example.baqtak.utils.TopNotice;
import com.example.baqtak.R;
import com.example.baqtak.data.auth.AuthFlow;
import com.example.baqtak.data.auth.AuthFlowState;
import com.example.baqtak.data.auth.AuthFlowListener;
import com.example.baqtak.ui.login.LoginActivity;
import com.example.baqtak.ui.otp.VerifyOtpActivity;
import com.example.baqtak.ui.resetpassword.NewPasswordActivity;

public abstract class AuthFlowActivity extends Activity implements AuthFlowListener, Runnable {
    protected String flowId;
    protected TopNotice notice;
    private String shownMessage = "";
    protected AuthFlowState flow;
    private final Handler clock = new Handler(Looper.getMainLooper());
    private boolean resumed, routing;
    private android.window.OnBackInvokedCallback backCallback;
    protected abstract int screenStage();
    protected abstract void render(AuthFlowState state);
    protected void tick(AuthFlowState state) { }

    protected final void initFlow(Bundle saved, boolean entry, boolean signup) {
        notice = new TopNotice(this);
        if (saved != null) flowId = saved.getString("flow_id");
        else flowId = getIntent().getStringExtra("flow_id");
        if (entry && saved == null && flowId == null) flowId = AuthFlow.create(signup).id;
        flow = AuthFlow.get(flowId);
        if (Build.VERSION.SDK_INT >= 33) {
            backCallback = this::handleBack;
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                    android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT, backCallback);
        }
    }
    @Override protected void onSaveInstanceState(Bundle out) {
        out.putString("flow_id", flowId); // An opaque identifier, never credentials.
        super.onSaveInstanceState(out);
    }
    @Override protected void onResume() {
        super.onResume(); resumed = true; routing = false;
        AuthFlow.attach(flowId, this);
        clock.removeCallbacks(this); clock.post(this);
    }
    @Override protected void onPause() {
        resumed = false; clock.removeCallbacks(this);
        notice.clear(); shownMessage = "";
        AuthFlow.detach(flowId, this);
        super.onPause();
    }
    @Override protected void onDestroy() {
        clock.removeCallbacks(this); AuthFlow.detach(flowId, this);
        if (Build.VERSION.SDK_INT >= 33 && backCallback != null) {
            getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback(backCallback);
        }
        super.onDestroy();
    }
    @Override public final void changed(AuthFlowState state) {
        if (!resumed || routing || isFinishing() || isDestroyed()) return;
        flow = state;
        if (state == null) {
            openLogin("انتهت العملية أو أعاد النظام تشغيل التطبيق. ابدأ من جديد."); return;
        }
        if (state.stage == AuthFlow.DONE && screenStage() != AuthFlow.DONE) {
            openStep(AuthSuccessActivity.class, true); return;
        }
        if (state.stage == AuthFlow.FORM && screenStage() != AuthFlow.FORM) {
            routing = true; finish(); return;
        }
        if (state.stage == AuthFlow.OTP && screenStage() != AuthFlow.OTP) {
            openStep(VerifyOtpActivity.class, false); return;
        }
        if (state.stage == AuthFlow.NEW_PASSWORD && screenStage() != AuthFlow.NEW_PASSWORD) {
            openStep(NewPasswordActivity.class, screenStage() == AuthFlow.OTP); return;
        }
        render(state); tick(state);
        if (state.busy || state.message.isEmpty()) { notice.clear(); shownMessage = ""; }
        else showStateMessage(state);
    }
    @Override public final void run() {
        if (!resumed || routing || isFinishing()) return;
        AuthFlowState current = AuthFlow.get(flowId);
        if (current == null) { changed(null); return; }
        tick(current); clock.postDelayed(this, 1000);
    }
    private void openStep(Class<?> type, boolean finishThis) {
        routing = true; hideKeyboard();
        startActivity(new Intent(this, type).putExtra("flow_id", flowId));
        overridePendingTransition(R.anim.auth_enter, R.anim.auth_exit);
        if (finishThis) finish();
    }
    protected final boolean blocked() {
        AuthFlowState s = AuthFlow.get(flowId);
        if (s != null && s.busy) {
            notice.info("انتظر اكتمال الطلب الجاري"); return true;
        }
        return false;
    }
    protected final void leaveToLogin() {
        if (blocked()) return;
        AuthFlow.discard(flowId); openLogin();
    }
    private void openLogin() { openLogin(""); }
    private void openLogin(String error) {
        if (routing) return;
        routing = true;
        Intent intent = new Intent(this, LoginActivity.class);
        intent.putExtra(TopNotice.EXTRA_ERROR, error);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent); finish();
    }
    protected void handleBack() {
        if (blocked()) return;
        if (screenStage() == AuthFlow.FORM) { AuthFlow.discard(flowId); finish(); }
        else { AuthFlow.backToForm(flowId); if (!isFinishing()) finish(); }
    }
    @Override public void onBackPressed() { handleBack(); }
    @Override public void finish() {
        super.finish(); overridePendingTransition(R.anim.auth_pop_enter, R.anim.auth_pop_exit);
    }
    protected final void toast(String text) { notice.error(text); }
    private void showStateMessage(AuthFlowState state) {
        String key = state.messageError + ":" + state.message;
        if (key.equals(shownMessage)) return;
        shownMessage = key;
        if (state.messageError) notice.error(state.message);
        else if (state.stage == AuthFlow.DONE && !state.signedIn) notice.info(state.message);
        else notice.success(state.message);
    }
    protected final void hideKeyboard() {
        View focused = getCurrentFocus();
        if (focused == null) focused = getWindow().getDecorView();
        InputMethodManager manager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (manager != null) manager.hideSoftInputFromWindow(focused.getWindowToken(), 0);
        focused.clearFocus();
    }
}
