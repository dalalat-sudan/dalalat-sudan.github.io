package com.example.baqtak.ui.otp;

import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import com.example.baqtak.R;
import com.example.baqtak.data.auth.AuthFlow;
import com.example.baqtak.data.auth.AuthFlowState;
import com.example.baqtak.data.auth.AuthRules;
import com.example.baqtak.ui.auth.AuthFlowActivity;
import com.example.baqtak.utils.AuthWindow;

public class VerifyOtpActivity extends AuthFlowActivity implements View.OnFocusChangeListener, View.OnKeyListener {
    private final EditText[] digits = new EditText[6];
    private Button verify;
    private TextView resend, change, login, email, message;
    private View progress;
    private boolean updating;
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
                | WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        setContentView(R.layout.activity_verify_otp); AuthWindow.setup(this, false);
        initFlow(state, false, false);
        verify = findViewById(R.id.btn_verify_otp); resend = findViewById(R.id.btn_resend_otp);
        change = findViewById(R.id.btn_change_email); login = findViewById(R.id.otp_login);
        email = findViewById(R.id.otp_email_info); message = findViewById(R.id.otp_message);
        progress = findViewById(R.id.otp_progress);
        int[] ids = {R.id.otp_digit_1, R.id.otp_digit_2, R.id.otp_digit_3,
                R.id.otp_digit_4, R.id.otp_digit_5, R.id.otp_digit_6};
        for (int i = 0; i < ids.length; i++) {
            digits[i] = findViewById(ids[i]); digits[i].setSaveEnabled(false);
            digits[i].setOnFocusChangeListener(this); digits[i].setOnKeyListener(this);
            digits[i].addTextChangedListener(new OtpTextWatcher(this, i)); border(digits[i]);
        }
        verify.setOnClickListener(v -> verify());
        resend.setOnClickListener(v -> {
            if (flow != null && !flow.busy && flow.resendSeconds() == 0 && flow.retrySeconds() == 0) {
                clearCode(); hideKeyboard(); AuthFlow.resend(flowId);
            }
        });
        change.setOnClickListener(v -> handleBack()); login.setOnClickListener(v -> leaveToLogin());
        digits[0].requestFocus();
    }
    @Override protected int screenStage() { return AuthFlow.OTP; }
    @Override protected void render(AuthFlowState state) {
        email.setText(state.email);
        for (EditText digit : digits) digit.setEnabled(!state.busy);
        change.setEnabled(!state.busy); login.setEnabled(!state.busy);
        progress.setVisibility(state.busy ? View.VISIBLE : View.GONE);
        message.setVisibility(View.GONE); // Messages are presented by AuthFlowActivity at the top.
    }
    @Override protected void tick(AuthFlowState state) {
        verify.setEnabled(!state.busy && state.retrySeconds() == 0);
        verify.setText(state.busy ? "جارٍ التحقق…" : state.retrySeconds() > 0
                ? "انتظر " + state.retrySeconds() + " ثانية" : "تحقّق من الرمز");
        int wait = Math.max(state.resendSeconds(), state.retrySeconds());
        resend.setEnabled(!state.busy && wait == 0);
        resend.setAlpha(resend.isEnabled() ? 1f : 0.55f);
        resend.setText(wait > 0 ? "إعادة إرسال الرمز بعد " + wait + " ثانية" : "إعادة إرسال الرمز");
    }
    private void verify() {
        if (flow == null || flow.busy || flow.retrySeconds() > 0) return;
        StringBuilder code = new StringBuilder();
        for (EditText digit : digits) {
            String value = digit.getText().toString();
            if (!value.matches("[0-9]")) { notice.error("أدخل الرقم"); digit.requestFocus(); return; }
            code.append(value);
        }
        hideKeyboard(); AuthFlow.verify(flowId, code.toString()); clearCode();
    }
    private void clearCode() {
        updating = true;
        for (EditText digit : digits) digit.setText("");
        updating = false;
    }
    void edited(int index, CharSequence text, int before, int inserted) {
        if (updating) return;
        String normalized = AuthRules.asciiDigits(text);
        updating = true;
        int next = index;
        if (normalized.isEmpty()) {
            digits[index].setText("");
            if (before > 0 && inserted == 0 && index > 0) next = index - 1;
        } else {
            for (int j = 0; j < normalized.length() && index + j < digits.length; j++) {
                digits[index + j].setText(normalized.substring(j, j + 1));
                digits[index + j].setSelection(1); next = Math.min(index + j + 1, 5);
            }
        }
        updating = false;
        digits[next].requestFocus();
        digits[next].setSelection(digits[next].length());
        boolean complete = true;
        for (EditText digit : digits) if (digit.length() != 1) complete = false;
        if (complete) hideKeyboard();
    }
    private void border(EditText input) {
        float density = getResources().getDisplayMetrics().density;
        GradientDrawable bg = new GradientDrawable(); bg.setColor(Color.WHITE); bg.setCornerRadius(12 * density);
        bg.setStroke(Math.round(density), input.hasFocus() ? Color.rgb(0, 57, 120) : Color.rgb(220, 225, 231));
        input.setBackground(bg);
    }
    @Override public void onFocusChange(View v, boolean focused) { border((EditText) v); }
    @Override public boolean onKey(View view, int keyCode, KeyEvent event) {
        if (keyCode != KeyEvent.KEYCODE_DEL || event.getAction() != KeyEvent.ACTION_DOWN) return false;
        for (int i = 1; i < digits.length; i++) {
            if (view == digits[i] && digits[i].length() == 0) {
                digits[i - 1].requestFocus(); digits[i - 1].setSelection(digits[i - 1].length()); return true;
            }
        }
        return false;
    }
}

class OtpTextWatcher implements TextWatcher {
    private final VerifyOtpActivity activity;
    private final int position;
    OtpTextWatcher(VerifyOtpActivity activity, int position) { this.activity = activity; this.position = position; }
    @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
    @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
        activity.edited(position, s, before, count);
    }
    @Override public void afterTextChanged(Editable e) { }
}
