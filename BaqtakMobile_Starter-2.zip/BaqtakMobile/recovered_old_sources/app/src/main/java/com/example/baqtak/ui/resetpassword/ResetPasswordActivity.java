package com.example.baqtak.ui.resetpassword;

import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import com.example.baqtak.R;
import com.example.baqtak.data.auth.AuthFlow;
import com.example.baqtak.data.auth.AuthFlowState;
import com.example.baqtak.ui.auth.AuthFlowActivity;
import com.example.baqtak.utils.AuthWindow;

public class ResetPasswordActivity extends AuthFlowActivity {
    private EditText email;
    private Button send;
    private TextView back, message;
    private View progress, inner;
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_reset_password); AuthWindow.setup(this, false);
        initFlow(state, true, false);
        email = findViewById(R.id.reset_email); inner = findViewById(R.id.reset_email_inner);
        send = findViewById(R.id.btn_send_reset); back = findViewById(R.id.btn_back_to_login);
        message = findViewById(R.id.reset_message); progress = findViewById(R.id.reset_progress);
        send.setOnClickListener(v -> attempt()); back.setOnClickListener(v -> leaveToLogin());
        email.setOnFocusChangeListener((v, focused) -> border(focused)); border(false);
        email.setOnEditorActionListener((v, action, event) -> {
            if (action == EditorInfo.IME_ACTION_DONE) { attempt(); return true; } return false;
        });
        if (flow != null) email.setText(flow.email);
    }
    private void border(boolean focused) {
        float density = getResources().getDisplayMetrics().density;
        GradientDrawable bg = new GradientDrawable(); bg.setColor(Color.WHITE);
        bg.setCornerRadius(18 * density);
        bg.setStroke(Math.round(density), focused ? Color.rgb(0, 57, 120) : Color.rgb(220, 225, 231));
        inner.setBackground(bg);
    }
    @Override protected int screenStage() { return AuthFlow.FORM; }
    @Override protected void render(AuthFlowState state) {
        email.setEnabled(!state.busy); back.setEnabled(!state.busy);
        progress.setVisibility(state.busy ? View.VISIBLE : View.GONE);
        message.setVisibility(View.GONE); // Messages are presented by AuthFlowActivity at the top.
    }
    @Override protected void tick(AuthFlowState state) {
        send.setEnabled(!state.busy && state.retrySeconds() == 0);
        send.setText(state.busy ? "جارٍ إرسال الرمز…" : state.retrySeconds() > 0
                ? "أعد المحاولة بعد " + state.retrySeconds() + " ثانية" : "إرسال رمز التحقق");
    }
    private void attempt() {
        if (flow == null || flow.busy || flow.retrySeconds() > 0) return;
        String address = email.getText().toString().trim();
        if (address.length() > 254 || !Patterns.EMAIL_ADDRESS.matcher(address).matches()) {
            notice.error("أدخل بريدًا إلكترونيًا صحيحًا"); email.requestFocus(); return;
        }
        hideKeyboard(); AuthFlow.startReset(flowId, address);
    }
}
