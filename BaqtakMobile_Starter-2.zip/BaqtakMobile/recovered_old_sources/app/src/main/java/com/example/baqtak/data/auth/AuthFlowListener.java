package com.example.baqtak.data.auth;

public interface AuthFlowListener {
    void changed(AuthFlowState state);
}
