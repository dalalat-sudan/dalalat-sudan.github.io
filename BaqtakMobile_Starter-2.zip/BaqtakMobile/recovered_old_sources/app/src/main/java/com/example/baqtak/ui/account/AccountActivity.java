package com.example.baqtak.ui.account;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import com.example.baqtak.utils.TopNotice;
import com.example.baqtak.R;
import com.example.baqtak.data.auth.AuthManager;
import com.example.baqtak.ui.login.LoginActivity;
import com.example.baqtak.utils.AuthWindow;

public class AccountActivity extends Activity implements AuthManager.Callback, View.OnClickListener {
    private TextView status, details;
    private TopNotice notice;
    private Button retry, logout;
    private View progress;
    private AuthManager.Request request;
    private boolean resumed, leaving;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_account);
        AuthWindow.setup(this, false);
        notice = new TopNotice(this);
        status = findViewById(R.id.account_status);
        details = findViewById(R.id.account_details);
        retry = findViewById(R.id.account_retry);
        logout = findViewById(R.id.account_logout);
        progress = findViewById(R.id.account_progress);
        retry.setOnClickListener(this);
        logout.setOnClickListener(this);
    }

    @Override protected void onResume() { super.onResume(); resumed = true; check(); }

    @Override protected void onPause() {
        resumed = false;
        notice.clear();
        if (request != null) { request.cancel(); request = null; }
        // Hide account details in the background until the next server check.
        details.setText("");
        super.onPause();
    }

    @Override protected void onDestroy() {
        if (request != null) request.cancel();
        super.onDestroy();
    }

    private void check() {
        if (leaving || request != null) return;
        busy("جارٍ التحقق من حسابك…");
        request = AuthManager.get(this).restore(this);
    }

    private void busy(String message) {
        notice.clear();
        status.setText(message);
        details.setText("");
        progress.setVisibility(View.VISIBLE);
        retry.setVisibility(View.GONE);
        logout.setEnabled(false);
    }

    @Override public void onClick(View view) {
        if (request != null || leaving) return;
        if (view.getId() == R.id.account_retry) check();
        else if (view.getId() == R.id.account_logout) {
            busy("جارٍ تسجيل الخروج…");
            request = AuthManager.get(this).logout(this);
        }
    }

    @Override public void complete(AuthManager.Result result) {
        request = null;
        if (!resumed || leaving || isFinishing() || isDestroyed()) return;
        progress.setVisibility(View.GONE);
        logout.setEnabled(true);
        if (result.state == AuthManager.Result.SIGNED_OUT) {
            leaving = true;
            
            Intent intent = new Intent(this, LoginActivity.class);
            intent.putExtra(TopNotice.EXTRA_ERROR, result.message);
            intent.putExtra(TopNotice.EXTRA_SUCCESS, "تم تسجيل الخروج".equals(result.message));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        } else if (result.state == AuthManager.Result.ERROR) {
            status.setText("");
            notice.retry(result.message, this::check);
            details.setText("");
            retry.setVisibility(View.VISIBLE);
        } else {
            notice.clear();
            status.setText(result.name.isEmpty() ? "مرحباً بك في باقتك" : "مرحباً، " + result.name);
            String text = result.email;
            if (!result.accountNumber.isEmpty()) text += "\nرقم الحساب: " + result.accountNumber;
            details.setText(text);
            retry.setVisibility(View.GONE);
        }
    }
}
