package com.example.baqtak.ui.splash;

import android.app.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import com.example.baqtak.utils.TopNotice;
import com.example.baqtak.R;
import com.example.baqtak.data.auth.AuthManager;
import com.example.baqtak.ui.account.AccountActivity;
import com.example.baqtak.ui.login.LoginActivity;
import com.example.baqtak.ui.onboarding.OnboardingActivity;
import com.example.baqtak.utils.AuthWindow;

public class SplashActivity extends Activity implements Runnable, AuthManager.Callback {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean navigated, resumed;
    private AuthManager.Request request;
    private TopNotice notice;
    private String routeMessage = "";

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_splash);
        AuthWindow.setup(this, true);
        notice = new TopNotice(this);
    }

    @Override protected void onResume() {
        super.onResume();
        resumed = true;
        handler.removeCallbacks(this);
        if (!navigated) handler.postDelayed(this, 2000);
    }

    @Override protected void onPause() {
        resumed = false;
        handler.removeCallbacks(this);
        if (request != null) { request.cancel(); request = null; }
        notice.clear();
        super.onPause();
    }

    @Override protected void onDestroy() {
        handler.removeCallbacks(this);
        if (request != null) request.cancel();
        super.onDestroy();
    }

    @Override public void run() {
        if (!resumed || navigated || isFinishing() || isDestroyed() || request != null) return;
        boolean completed = getSharedPreferences("baqtak_preferences", MODE_PRIVATE)
                .getBoolean("onboarding_completed", false);
        if (!completed) { open(OnboardingActivity.class); return; }
        notice.clear();
        request = AuthManager.get(this).restore(this);
    }

    @Override public void complete(AuthManager.Result result) {
        request = null;
        if (!resumed || navigated || isFinishing() || isDestroyed()) return;
        if (result.state == AuthManager.Result.READY) open(AccountActivity.class);
        else if (result.state == AuthManager.Result.SIGNED_OUT) {
            routeMessage = result.message;
            open(LoginActivity.class);
        } else {
            notice.retry(result.message, this);
        }
    }

    private void open(Class<?> destination) {
        if (navigated) return;
        navigated = true;
        startActivity(new Intent(this, destination).putExtra(TopNotice.EXTRA_ERROR, routeMessage));
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        finish();
    }
}
