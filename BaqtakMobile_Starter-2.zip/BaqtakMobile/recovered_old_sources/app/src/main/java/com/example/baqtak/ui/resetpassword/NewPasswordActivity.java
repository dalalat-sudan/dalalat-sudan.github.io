package com.example.baqtak.ui.resetpassword;

import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.example.baqtak.R;
import com.example.baqtak.data.auth.AuthFlow;
import com.example.baqtak.data.auth.AuthFlowState;
import com.example.baqtak.data.auth.AuthRules;
import com.example.baqtak.ui.auth.AuthFields;
import com.example.baqtak.ui.auth.AuthFlowActivity;
import com.example.baqtak.utils.AuthWindow;

public class NewPasswordActivity extends AuthFlowActivity {
    private EditText password, confirmation;
    private Button save;
    private TextView message, back, login;
    private View progress;
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_new_password); AuthWindow.setup(this, false);
        initFlow(state, false, false);
        LinearLayout fields = findViewById(R.id.new_password_fields);
        int type = InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD;
        password = AuthFields.add(this, fields, 1101, "أدخل كلمة المرور الجديدة", "كلمة المرور الجديدة", type, true);
        confirmation = AuthFields.add(this, fields, 1102, "أعد إدخال كلمة المرور", "تأكيد كلمة المرور", type, true);
        password.setNextFocusForwardId(confirmation.getId()); confirmation.setImeOptions(EditorInfo.IME_ACTION_DONE);
        confirmation.setOnEditorActionListener((v, action, event) -> {
            if (action == EditorInfo.IME_ACTION_DONE) { attempt(); return true; } return false;
        });
        save = findViewById(R.id.btn_save_new_password); progress = findViewById(R.id.new_password_progress);
        message = findViewById(R.id.new_password_message); back = findViewById(R.id.btn_restart_reset);
        login = findViewById(R.id.new_password_login);
        save.setOnClickListener(v -> attempt()); back.setOnClickListener(v -> handleBack());
        login.setOnClickListener(v -> leaveToLogin());
    }
    @Override protected int screenStage() { return AuthFlow.NEW_PASSWORD; }
    @Override protected void render(AuthFlowState state) {
        password.setEnabled(!state.busy); confirmation.setEnabled(!state.busy);
        back.setEnabled(!state.busy); login.setEnabled(!state.busy);
        progress.setVisibility(state.busy ? View.VISIBLE : View.GONE);
        message.setVisibility(View.GONE); // Messages are presented by AuthFlowActivity at the top.
    }
    @Override protected void tick(AuthFlowState state) {
        boolean expired = state.ticketSeconds() == 0;
        save.setEnabled(!state.busy && !expired && state.retrySeconds() == 0);
        save.setText(state.busy ? "جارٍ حفظ كلمة المرور…" : expired ? "انتهت صلاحية العملية"
                : state.retrySeconds() > 0 ? "انتظر " + state.retrySeconds() + " ثانية" : "حفظ كلمة المرور");

    }
    private void attempt() {
        if (flow == null || flow.busy || flow.retrySeconds() > 0 || flow.ticketSeconds() == 0) return;
        String pass = password.getText().toString();
        String error = AuthRules.passwordError(pass);
        if (!error.isEmpty()) { notice.error(error); password.requestFocus(); return; }
        if (!pass.equals(confirmation.getText().toString())) {
            notice.error("كلمتا المرور غير متطابقتين"); confirmation.requestFocus(); return;
        }
        hideKeyboard(); AuthFlow.completeReset(flowId, pass);
        password.setText(""); confirmation.setText("");
    }
}
