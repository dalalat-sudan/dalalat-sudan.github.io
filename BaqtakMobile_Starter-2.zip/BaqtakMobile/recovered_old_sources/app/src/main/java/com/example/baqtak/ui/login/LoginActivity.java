package com.example.baqtak.ui.login;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Patterns;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.TextView;
import com.example.baqtak.utils.TopNotice;
import com.example.baqtak.R;
import com.example.baqtak.data.auth.AuthManager;
import com.example.baqtak.ui.account.AccountActivity;
import com.example.baqtak.ui.register.RegisterActivity;
import com.example.baqtak.ui.resetpassword.ResetPasswordActivity;
import com.example.baqtak.utils.AuthWindow;

public class LoginActivity extends Activity implements TextWatcher,
        View.OnClickListener, View.OnFocusChangeListener, AuthManager.Callback {

    private static final int PRIMARY_BLUE = Color.rgb(0, 57, 120);
    private static final int BORDER_GRAY = Color.rgb(220, 225, 231);
    private EditText emailInput, passwordInput;
    private FrameLayout emailBox, passwordBox;
    private TextView emailLabel, passwordLabel, forgotPassword, createAccount;
    private ImageButton passwordToggle;
    private Button loginButton;
    private boolean passwordVisible, openingRegister, openingResetPassword;
    private boolean busy, resumed, navigated;
    private AuthManager.Request request;
    private AuthManager.Result pending;
    private TopNotice notice;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_login);
        AuthWindow.setup(this, false);
        notice = new TopNotice(this);
        emailInput = findViewById(R.id.login_email);
        passwordInput = findViewById(R.id.login_password);
        emailBox = findViewById(R.id.email_field_box);
        passwordBox = findViewById(R.id.password_field_box);
        emailLabel = findViewById(R.id.email_floating_label);
        passwordLabel = findViewById(R.id.password_floating_label);
        passwordToggle = findViewById(R.id.password_visibility_toggle);
        loginButton = findViewById(R.id.btn_login);
        forgotPassword = findViewById(R.id.btn_forgot_password);
        createAccount = findViewById(R.id.btn_create_account);

        emailInput.setOnFocusChangeListener(this);
        passwordInput.setOnFocusChangeListener(this);
        emailInput.addTextChangedListener(this);
        passwordInput.addTextChangedListener(this);
        passwordInput.setSaveEnabled(false);
        passwordInput.setTransformationMethod(PasswordTransformationMethod.getInstance());
        passwordToggle.setImageResource(R.drawable.ic_visibility_off);
        passwordToggle.setContentDescription("إظهار كلمة المرور");
        passwordInput.setOnEditorActionListener((view, id, event) -> {
            if (id == EditorInfo.IME_ACTION_DONE) { attemptLogin(); return true; }
            return false;
        });
        loginButton.setOnClickListener(this);
        forgotPassword.setOnClickListener(this);
        createAccount.setOnClickListener(this);
        passwordToggle.setOnClickListener(this);
        updateAllFields();

        // Also recovers a sign-in that finished while the previous screen rotated.
        setBusy(true);
        loginButton.setText("جارٍ فحص الجلسة…");
        request = AuthManager.get(this).restore(this);
    }

    @Override protected void onResume() {
        super.onResume();
        resumed = true;
        String incoming = getIntent().getStringExtra(TopNotice.EXTRA_ERROR);
        getIntent().removeExtra(TopNotice.EXTRA_ERROR);
        boolean success = getIntent().getBooleanExtra(TopNotice.EXTRA_SUCCESS, false);
        getIntent().removeExtra(TopNotice.EXTRA_SUCCESS);
        if (incoming != null && !incoming.isEmpty()) {
            if (success) notice.success(incoming); else notice.error(incoming);
        }
        openingRegister = false;
        openingResetPassword = false;
        if (pending != null) {
            AuthManager.Result result = pending;
            pending = null;
            complete(result);
        }
    }

    @Override protected void onPause() { resumed = false; notice.clear(); super.onPause(); }
    @Override protected void onDestroy() {
        if (request != null) request.cancel();
        pending = null;
        super.onDestroy();
    }

    @Override public void complete(AuthManager.Result result) {
        request = null;
        if (isFinishing() || isDestroyed() || navigated) return;
        if (!resumed) { pending = result; return; }
        setBusy(false);
        if (result.state == AuthManager.Result.READY) {
            navigated = true;
            passwordInput.setText("");
            Intent intent = new Intent(this, AccountActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        } else if (!result.message.isEmpty()) {
            notice.error(result.message);
        }
    }

    private void setBusy(boolean value) {
        busy = value;
        if (value) notice.clear();
        loginButton.setEnabled(!value);
        loginButton.setText(value ? "جارٍ تسجيل الدخول…" : "تسجيل الدخول");
        emailInput.setEnabled(!value);
        passwordInput.setEnabled(!value);
        passwordToggle.setEnabled(!value);
        forgotPassword.setEnabled(!value);
        createAccount.setEnabled(!value);
    }

    @Override public void onClick(View view) {
        if (busy) return;
        int id = view.getId();
        if (id == R.id.btn_login) attemptLogin();
        else if (id == R.id.password_visibility_toggle) togglePasswordVisibility();
        else if (id == R.id.btn_create_account && !openingRegister) {
            openingRegister = true;
            hideKeyboard();
            startActivity(new Intent(this, RegisterActivity.class));
            overridePendingTransition(R.anim.auth_enter, R.anim.auth_exit);
        } else if (id == R.id.btn_forgot_password && !openingResetPassword) {
            openingResetPassword = true;
            hideKeyboard();
            startActivity(new Intent(this, ResetPasswordActivity.class));
            overridePendingTransition(R.anim.auth_enter, R.anim.auth_exit);
        }
    }

    private void attemptLogin() {
        if (busy || navigated) return;
        String email = emailInput.getText().toString().trim();
        String password = passwordInput.getText().toString();
        if (email.isEmpty()) {
            notice.error("أدخل بريدك الإلكتروني"); emailInput.requestFocus(); return;
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            notice.error("أدخل بريدًا إلكترونيًا صحيحًا"); emailInput.requestFocus(); return;
        }
        if (password.isEmpty()) {
            notice.error("أدخل كلمة المرور"); passwordInput.requestFocus(); return;
        }
        hideKeyboard();
        setBusy(true);
        request = AuthManager.get(this).login(email, password, this);
    }

    @Override public void onFocusChange(View view, boolean focus) { updateAllFields(); }
    @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
    @Override public void onTextChanged(CharSequence s, int start, int before, int count) { updateAllFields(); }
    @Override public void afterTextChanged(Editable editable) { }

    private void updateAllFields() {
        updateField(emailInput, emailBox, emailLabel, "أدخل بريدك الإلكتروني");
        updateField(passwordInput, passwordBox, passwordLabel, "أدخل كلمة المرور");
    }

    private void updateField(EditText input, FrameLayout box, TextView label, String hint) {
        boolean focused = input.hasFocus();
        boolean floating = focused || input.length() > 0;
        label.setVisibility(floating ? View.VISIBLE : View.GONE);
        input.setHint(floating ? "" : hint);
        GradientDrawable background = new GradientDrawable();
        background.setColor(Color.WHITE);
        background.setCornerRadius(dp(18));
        background.setStroke(dp(1), focused ? PRIMARY_BLUE : BORDER_GRAY);
        box.setBackground(background);
        label.setTextColor(PRIMARY_BLUE);
    }

    private void togglePasswordVisibility() {
        int cursor = passwordInput.getSelectionStart();
        passwordVisible = !passwordVisible;
        passwordInput.setTransformationMethod(passwordVisible
                ? HideReturnsTransformationMethod.getInstance()
                : PasswordTransformationMethod.getInstance());
        passwordToggle.setImageResource(passwordVisible ? R.drawable.ic_visibility : R.drawable.ic_visibility_off);
        passwordToggle.setContentDescription(passwordVisible ? "إخفاء كلمة المرور" : "إظهار كلمة المرور");
        if (cursor >= 0) passwordInput.setSelection(Math.min(cursor, passwordInput.length()));
        passwordInput.requestFocus();
    }

    private void hideKeyboard() {
        View focused = getCurrentFocus();
        if (focused == null) focused = getWindow().getDecorView();
        InputMethodManager keyboard = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (keyboard != null) keyboard.hideSoftInputFromWindow(focused.getWindowToken(), 0);
        focused.clearFocus();
    }

    private int dp(float value) { return Math.round(value * getResources().getDisplayMetrics().density); }
}
