package com.example.baqtak.ui.register;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.util.Patterns;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.example.baqtak.R;
import com.example.baqtak.data.auth.AuthFlow;
import com.example.baqtak.data.auth.AuthFlowState;
import com.example.baqtak.data.auth.AuthRules;
import com.example.baqtak.ui.auth.AuthFields;
import com.example.baqtak.ui.auth.AuthFlowActivity;
import com.example.baqtak.ui.terms.TermsActivity;
import com.example.baqtak.utils.AuthWindow;

public class RegisterActivity extends AuthFlowActivity {
    private EditText first, second, family, email, password, confirmation;
    private CheckBox terms;
    private Button submit;
    private TextView message, back, termsLink;
    private View progress;
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
                | WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        setContentView(R.layout.activity_register); AuthWindow.setup(this, false);
        initFlow(state, true, true);
        LinearLayout fields = findViewById(R.id.register_fields);
        int name = InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PERSON_NAME;
        int pass = InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD;
        first = AuthFields.add(this, fields, 1001, "أدخل اسمك الأول", "الاسم الأول", name, false);
        second = AuthFields.add(this, fields, 1002, "أدخل اسمك الثاني", "الاسم الثاني", name, false);
        family = AuthFields.add(this, fields, 1003, "أدخل اسم العائلة", "اسم العائلة", name, false);
        email = AuthFields.add(this, fields, 1004, "أدخل بريدك الإلكتروني", "البريد الإلكتروني",
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS, false);
        password = AuthFields.add(this, fields, 1005, "أدخل كلمة المرور", "كلمة المرور", pass, true);
        confirmation = AuthFields.add(this, fields, 1006, "أعد إدخال كلمة المرور", "تأكيد كلمة المرور", pass, true);
        first.setNextFocusForwardId(second.getId()); second.setNextFocusForwardId(family.getId());
        family.setNextFocusForwardId(email.getId()); email.setNextFocusForwardId(password.getId());
        password.setNextFocusForwardId(confirmation.getId());
        confirmation.setImeOptions(EditorInfo.IME_ACTION_DONE);
        confirmation.setOnEditorActionListener((v, action, event) -> {
            if (action == EditorInfo.IME_ACTION_DONE) { attempt(); return true; } return false;
        });
        terms = findViewById(R.id.register_terms);
        submit = findViewById(R.id.btn_register); message = findViewById(R.id.register_message);
        progress = findViewById(R.id.register_progress);
        back = findViewById(R.id.btn_back_to_login); termsLink = findViewById(R.id.btn_open_terms);
        submit.setOnClickListener(v -> attempt()); back.setOnClickListener(v -> leaveToLogin());
        termsLink.setOnClickListener(v -> {
            if (!blocked()) startActivity(new Intent(this, TermsActivity.class));
        });
        if (flow != null) {
            first.setText(flow.first); second.setText(flow.second); family.setText(flow.family); email.setText(flow.email);
        }
    }
    @Override protected int screenStage() { return AuthFlow.FORM; }
    @Override protected void render(AuthFlowState state) {
        boolean enabled = !state.busy;
        for (EditText field : new EditText[]{first, second, family, email, password, confirmation}) field.setEnabled(enabled);
        terms.setEnabled(enabled); termsLink.setEnabled(enabled); back.setEnabled(enabled);
        progress.setVisibility(state.busy ? View.VISIBLE : View.GONE);
        message.setVisibility(View.GONE); // Messages are presented by AuthFlowActivity at the top.
    }
    @Override protected void tick(AuthFlowState state) {
        submit.setEnabled(!state.busy && state.retrySeconds() == 0);
        submit.setText(state.busy ? "جارٍ إرسال الرمز…" : state.retrySeconds() > 0
                ? "أعد المحاولة بعد " + state.retrySeconds() + " ثانية" : "إنشاء حساب");
    }
    private void attempt() {
        if (flow == null || flow.busy || flow.retrySeconds() > 0) return;
        for (EditText input : new EditText[]{first, second, family}) {
            String error = AuthRules.nameError(input.getText().toString());
            if (!error.isEmpty()) { notice.error(error); input.requestFocus(); return; }
        }
        String address = email.getText().toString().trim();
        if (address.length() > 254 || !Patterns.EMAIL_ADDRESS.matcher(address).matches()) {
            notice.error("أدخل بريدًا إلكترونيًا صحيحًا"); email.requestFocus(); return;
        }
        String pass = password.getText().toString();
        String error = AuthRules.passwordError(pass);
        if (!error.isEmpty()) { notice.error(error); password.requestFocus(); return; }
        if (!pass.equals(confirmation.getText().toString())) {
            notice.error("كلمتا المرور غير متطابقتين"); confirmation.requestFocus(); return;
        }
        if (!terms.isChecked()) { toast("يرجى الموافقة على الشروط والأحكام للمتابعة"); return; }
        hideKeyboard();
        AuthFlow.startSignup(flowId, first.getText().toString(), second.getText().toString(),
                family.getText().toString(), address, pass);
    }
}
