package com.example.baqtak.data.auth;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONObject;

// All state and listeners live on the main thread. HTTP work is serialized separately.
// Passwords, OTPs and reset tickets never enter Intent extras, saved state, disk or logs.
public final class AuthFlow {
    public static final int FORM = 0, OTP = 1, NEW_PASSWORD = 2, DONE = 3;
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final ExecutorService WORKER = Executors.newSingleThreadExecutor();
    private static final Map<String, AuthFlowState> FLOWS = new HashMap<>();
    private AuthFlow() { }
    public static AuthFlowState create(boolean signup) {
        // One account flow at a time; cancel any abandoned draft.
        for (AuthFlowState old : FLOWS.values()) erase(old);
        FLOWS.clear();
        AuthFlowState state = new AuthFlowState(signup);
        FLOWS.put(state.id, state);
        MAIN.postDelayed(() -> expire(state), 30 * 60 * 1000L);
        return state;
    }
    public static AuthFlowState get(String id) {
        AuthFlowState state = FLOWS.get(id);
        if (state != null && SystemClock.elapsedRealtime() >= state.expires && !state.busy) {
            expire(state); return null;
        }
        return state;
    }
    private static void expire(AuthFlowState state) {
        if (FLOWS.get(state.id) != state) return;
        if (state.busy) { MAIN.postDelayed(() -> expire(state), 1000); return; }
        AuthFlowListener listener = state.listener;
        erase(state); FLOWS.remove(state.id);
        if (listener != null) listener.changed(null);
    }
    public static void attach(String id, AuthFlowListener listener) {
        AuthFlowState state = get(id);
        if (state != null) state.listener = listener;
        listener.changed(state);
    }
    public static void detach(String id, AuthFlowListener listener) {
        AuthFlowState state = FLOWS.get(id);
        if (state != null && state.listener == listener) state.listener = null;
    }
    public static void discard(String id) {
        AuthFlowState state = FLOWS.remove(id);
        if (state != null) erase(state);
    }
    private static void erase(AuthFlowState state) {
        state.password = ""; state.ticket = ""; state.email = "";
        state.first = ""; state.second = ""; state.family = ""; state.listener = null;
    }
    public static void backToForm(String id) {
        AuthFlowState state = get(id);
        if (state == null || state.busy) return;
        state.stage = FORM; state.password = ""; state.ticket = "";
        state.setMessage("", false);
        notifyState(state);
    }
    public static void startSignup(String id, String first, String second, String family,
                                   String email, String password) {
        AuthFlowState s = get(id);
        if (!available(s, FORM)) return;
        s.first = first.trim(); s.second = second.trim(); s.family = family.trim();
        s.email = email.trim().toLowerCase(Locale.ROOT); s.password = password;
        try { send(s, "signup/start", signupBody(s), "start"); }
        catch (Exception e) { failedLocally(s); }
    }
    public static void startReset(String id, String email) {
        AuthFlowState s = get(id);
        if (!available(s, FORM)) return;
        s.email = email.trim().toLowerCase(Locale.ROOT);
        try { send(s, "password-reset/request", emailBody(s), "start"); }
        catch (Exception e) { failedLocally(s); }
    }
    public static void resend(String id) {
        AuthFlowState s = get(id);
        if (!available(s, OTP) || s.resendSeconds() > 0) return;
        try { send(s, s.signup ? "signup/resend" : "password-reset/request", emailBody(s), "resend"); }
        catch (Exception e) { failedLocally(s); }
    }
    public static void verify(String id, String code) {
        AuthFlowState s = get(id);
        if (!available(s, OTP)) return;
        if (!code.matches("[0-9]{6}")) { s.setMessage("أدخل الرمز المكوّن من 6 أرقام", true); notifyState(s); return; }
        try {
            JSONObject body = s.signup ? signupBody(s) : emailBody(s);
            send(s, s.signup ? "signup/verify" : "password-reset/verify", body.put("code", code), "verify");
        } catch (Exception e) { failedLocally(s); }
    }
    public static void completeReset(String id, String password) {
        AuthFlowState s = get(id);
        if (!available(s, NEW_PASSWORD)) return;
        if (s.ticketSeconds() <= 0) {
            s.ticket = ""; s.setMessage("انتهت صلاحية العملية. ارجع واطلب رمزًا جديدًا.", true);
            notifyState(s); return;
        }
        s.password = password;
        try {
            send(s, "password-reset/complete", emailBody(s).put("ticket", s.ticket)
                    .put("password", password), "complete");
        } catch (Exception e) { failedLocally(s); }
    }
    public static void signIn(String id, Context context) {
        AuthFlowState s = get(id);
        if (s == null || s.stage != DONE || s.busy || s.signedIn) return;
        s.loginAttempted = true;
        if (s.password.isEmpty()) {
            s.setMessage("اكتملت العملية. سجّل الدخول يدويًا للمتابعة.", false);
            notifyState(s); return;
        }
        s.busy = true; s.setMessage("جارٍ تسجيل دخولك والتحقق من حسابك…", false);
        notifyState(s);
        AuthManager manager = AuthManager.get(context.getApplicationContext());
        // Clear any old account's session before signing in to this verified email.
        manager.logout(cleared -> {
            if (FLOWS.get(s.id) != s) return;
            if (cleared.state == AuthManager.Result.ERROR) {
                s.busy = false;
                s.setMessage("اكتملت العملية، لكن تعذّر تجهيز الجلسة. أعد محاولة الدخول.", true);
                notifyState(s); return;
            }
            manager.login(s.email, s.password, result -> {
                if (FLOWS.get(s.id) != s) return;
                s.busy = false;
                if (result.state == AuthManager.Result.READY) {
                    s.signedIn = true; s.password = "";
                    s.setMessage("أهلاً بك في باقتك. جارٍ الانتقال إلى حسابك…", false);
                } else {
                    if (result.state == AuthManager.Result.SIGNED_OUT) s.password = "";
                    s.setMessage("اكتملت العملية، لكن تعذّر الدخول التلقائي. " + result.message, true);
                }
                notifyState(s);
            });
        });
    }
    private static boolean available(AuthFlowState s, int stage) {
        return s != null && !s.busy && s.stage == stage && s.retrySeconds() == 0;
    }
    private static JSONObject emailBody(AuthFlowState s) throws Exception { return new JSONObject().put("email", s.email); }
    private static JSONObject signupBody(AuthFlowState s) throws Exception {
        return emailBody(s).put("password", s.password).put("firstName", s.first)
                .put("secondName", s.second).put("thirdName", s.family);
    }
    private static void failedLocally(AuthFlowState s) {
        s.busy = false; s.setMessage("تعذّر تجهيز الطلب. أعد المحاولة.", true); notifyState(s);
    }
    private static void notifyState(AuthFlowState s) { if (s.listener != null) s.listener.changed(s); }
    private static void send(AuthFlowState s, String path, JSONObject body, String operation) {
        s.busy = true; s.setMessage("", false); notifyState(s);
        WORKER.execute(() -> {
            PublicAuthHttp.Reply reply;
            try { reply = PublicAuthHttp.post(path, body); }
            catch (Exception e) {
                reply = new PublicAuthHttp.Reply(false, 0, 60,
                        "تعذّر التأكد من نتيجة الطلب. تحقق من الإنترنت. إذا اكتمل إنشاء الحساب أو تغيير كلمة المرور، جرّب تسجيل الدخول قبل إعادة العملية.", "");
            }
            // Clear references as soon as the request finishes; no automatic retries.
            body.remove("password"); body.remove("code"); body.remove("ticket");
            PublicAuthHttp.Reply result = reply;
            MAIN.post(() -> {
                if (FLOWS.get(s.id) != s) return;
                s.busy = false;
                if (!result.ok) {
                    s.setMessage(result.message, true);
                    if (result.status == 429) {
                        s.retryAt = SystemClock.elapsedRealtime() + result.retrySeconds * 1000L;
                        s.resendAt = Math.max(s.resendAt, s.retryAt);
                    }
                    if (operation.equals("start") || operation.equals("complete")) s.password = "";
                    notifyState(s); return;
                }
                long now = SystemClock.elapsedRealtime();
                if (operation.equals("start") || operation.equals("resend")) {
                    s.stage = OTP; s.resendAt = now + 60000L;
                    s.setMessage("تم طلب إرسال الرمز. تحقق من بريدك ومجلد الرسائل غير المرغوبة.", false);
                } else if (operation.equals("verify") && !s.signup) {
                    if (!result.ticket.matches("[a-fA-F0-9]{64}")) {
                        s.setMessage("تعذّر استلام تصريح تغيير كلمة المرور. ارجع واطلب رمزًا جديدًا.", true);
                    } else {
                        s.ticket = result.ticket; s.ticketExpires = now + 10 * 60 * 1000L;
                        s.stage = NEW_PASSWORD;
                        MAIN.postDelayed(() -> {
                            if (FLOWS.get(s.id) == s && s.stage == NEW_PASSWORD && !s.busy && s.ticketSeconds() == 0) {
                                s.ticket = ""; s.setMessage("انتهت صلاحية العملية. ارجع واطلب رمزًا جديدًا.", true);
                                notifyState(s);
                            }
                        }, 10 * 60 * 1000L);
                    }
                } else {
                    s.stage = DONE; s.ticket = "";
                    s.setMessage(s.signup ? "تم إنشاء حسابك بنجاح"
                            : "تم تغيير كلمة المرور بنجاح", false);
                }
                notifyState(s);
            });
        });
    }
}
