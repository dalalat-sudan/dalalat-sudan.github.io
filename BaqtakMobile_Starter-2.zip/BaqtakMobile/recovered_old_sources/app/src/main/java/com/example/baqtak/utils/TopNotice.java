package com.example.baqtak.utils;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import com.example.baqtak.R;

/** An in-app notice, inside the inset-aware content area; no overlay permission. */
public final class TopNotice implements View.OnClickListener {
    public static final String EXTRA_SUCCESS = "baqtak_notice_success";
    public static final String EXTRA_ERROR = "baqtak_notice_error";
    private final Activity activity;
    private final FrameLayout host;
    private final LinearLayout card;
    private final TextView title, body, symbol, close, action;
    private Runnable retry;

    public TopNotice(Activity activity) {
        this.activity = activity;
        host = activity.findViewById(android.R.id.content);
        card = new LinearLayout(activity);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        card.setPadding(dp(12), dp(4), dp(12), dp(12));
        card.setElevation(dp(12));
        card.setClickable(true);
        card.setVisibility(View.GONE);
        LinearLayout header = new LinearLayout(activity);
        header.setGravity(Gravity.CENTER_VERTICAL);
        symbol = text(20, true);
        symbol.setGravity(Gravity.CENTER);
        symbol.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        header.addView(symbol, new LinearLayout.LayoutParams(dp(32), dp(48)));
        title = text(14, true);
        header.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        close = text(24, false);
        close.setText("×"); close.setGravity(Gravity.CENTER);
        close.setContentDescription("إغلاق الرسالة");
        close.setOnClickListener(this); close.setFocusable(true);
        header.addView(close, new LinearLayout.LayoutParams(dp(48), dp(48)));
        card.addView(header);
        ScrollView scroll = new NoticeScrollView(activity);
        scroll.setFillViewport(false);
        body = text(13, false);
        body.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
        body.setLineSpacing(dp(2), 1f);
        // Wrap all text, with scrolling for long messages or enlarged system fonts.
        scroll.addView(body, new ScrollView.LayoutParams(-1, -2));
        card.addView(scroll, new LinearLayout.LayoutParams(-1, -2));
        action = text(13, true);
        action.setMinHeight(dp(48)); action.setGravity(Gravity.CENTER);
        action.setOnClickListener(this); action.setFocusable(true);
        card.addView(action, new LinearLayout.LayoutParams(-1, -2));
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(-1, -2, Gravity.TOP);
        params.setMargins(dp(16), dp(12), dp(16), 0);
        host.addView(card, params);
    }
    public void error(String message) { show(message, true, false, null); }
    public void info(String message) { show(message, false, false, null); }
    public void success(String message) { show(message, false, true, null); }
    public void retry(String message, Runnable callback) { show(message, true, false, callback); }
    private void show(String message, boolean error, boolean success, Runnable callback) {
        if (activity.isFinishing() || activity.isDestroyed()) return;
        if (message == null || message.trim().isEmpty()) { clear(); return; }
        retry = callback;
        int ink = Color.parseColor(error ? "#991B1B" : success ? "#166534" : "#003978");
        GradientDrawable background = new GradientDrawable();
        background.setColor(Color.parseColor(error ? "#FFF1F2" : success ? "#F0FDF4" : "#EFF6FF"));
        background.setCornerRadius(dp(18));
        background.setStroke(dp(1), Color.parseColor(error ? "#FDA4AF" : success ? "#86EFAC" : "#93C5FD"));
        card.setBackground(background);
        title.setText(error ? "تعذّر إكمال الطلب" : success ? "تم بنجاح" : "تنبيه");
        symbol.setText(error ? "!" : success ? "✓" : "i");
        for (TextView view : new TextView[]{title, body, symbol, close, action}) view.setTextColor(ink);
        action.setText("إعادة المحاولة");
        action.setVisibility(callback == null ? View.GONE : View.VISIBLE);
        // Retry notices remain actionable until resolved. Other notices can be dismissed.
        close.setVisibility(callback == null ? View.VISIBLE : View.GONE);
        card.animate().cancel(); card.setAlpha(1f); card.setTranslationY(0f);
        card.setVisibility(View.VISIBLE); card.bringToFront();
        body.setText(message);
        card.setAlpha(0f); card.setTranslationY(-dp(12));
        card.animate().alpha(1f).translationY(0f).setDuration(180).start();
    }
    public void clear() {
        retry = null; card.animate().cancel();
        card.setVisibility(View.GONE); body.setText("");
    }
    @Override public void onClick(View view) {
        Runnable callback = retry;
        clear();
        if (view == action && callback != null) callback.run();
    }
    private TextView text(int size, boolean bold) {
        TextView view = new TextView(activity);
        view.setTextSize(size);
        view.setTypeface(activity.getResources().getFont(bold ? R.font.cairo_bold : R.font.cairo_regular));
        view.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        view.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG_RTL);
        view.setIncludeFontPadding(false);
        return view;
    }
    private int dp(float value) { return Math.round(value * activity.getResources().getDisplayMetrics().density); }
}
