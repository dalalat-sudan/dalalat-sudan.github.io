package com.example.baqtak.ui.auth;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import com.example.baqtak.R;
import com.example.baqtak.data.auth.AuthFlow;
import com.example.baqtak.data.auth.AuthFlowState;
import com.example.baqtak.ui.account.AccountActivity;
import com.example.baqtak.utils.AuthWindow;

public class AuthSuccessActivity extends AuthFlowActivity {
    private TextView title, status, manual;
    private Button action;
    private View progress;
    private final Handler delay = new Handler(Looper.getMainLooper());
    private final Runnable enter = this::openAccount;
    private boolean entering;

    @Override protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        setContentView(R.layout.activity_auth_success);
        AuthWindow.setup(this, false);
        initFlow(saved, false, false);
        title = findViewById(R.id.success_title);
        status = findViewById(R.id.success_status);
        manual = findViewById(R.id.success_manual_login);
        action = findViewById(R.id.success_action);
        progress = findViewById(R.id.success_progress);
        action.setOnClickListener(v -> {
            if (flow != null && flow.signedIn) openAccount();
            else AuthFlow.signIn(flowId, this);
        });
        manual.setOnClickListener(v -> leaveToLogin());
    }

    @Override protected int screenStage() { return AuthFlow.DONE; }

    @Override protected void render(AuthFlowState state) {
        title.setText(state.signup ? "تم إنشاء حسابك بنجاح" : "تم تغيير كلمة المرور بنجاح");
        status.setText(state.messageError ? "يمكنك إعادة المحاولة أو تسجيل الدخول يدويًا." : state.message);
        progress.setVisibility(state.busy ? View.VISIBLE : View.GONE);
        action.setEnabled(!state.busy);
        action.setText(state.signedIn ? "الدخول الآن" : state.busy ? "جارٍ تسجيل الدخول…" : "إعادة محاولة الدخول");
        manual.setVisibility(!state.busy && !state.signedIn && state.loginAttempted ? View.VISIBLE : View.GONE);
        if (state.signedIn) {
            delay.removeCallbacks(enter);
            delay.postDelayed(enter, 1400);
        } else if (!state.loginAttempted) {
            AuthFlow.signIn(flowId, this);
        }
    }

    @Override protected void onPause() {
        delay.removeCallbacks(enter);
        super.onPause();
    }
    @Override protected void onDestroy() {
        delay.removeCallbacks(enter);
        super.onDestroy();
    }
    @Override protected void handleBack() {
        if (flow != null && flow.signedIn) openAccount();
        else leaveToLogin();
    }

    private void openAccount() {
        if (entering || isFinishing() || isDestroyed()) return;
        AuthFlowState state = AuthFlow.get(flowId);
        if (state == null || !state.signedIn) return;
        entering = true;
        delay.removeCallbacks(enter);
        AuthFlow.discard(flowId);
        Intent intent = new Intent(this, AccountActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }
}
