package com.example.baqtak.data.auth;

import android.os.SystemClock;
import java.util.UUID;

public final class AuthFlowState {
        public final String id;
        public final boolean signup;
        public String email = "", first = "", second = "", family = "";
        public String message = "";
        public boolean messageError;
        public void setMessage(String text, boolean error) { message = text; messageError = error; }
        public int stage = AuthFlow.FORM;
        public boolean busy, loginAttempted, signedIn;
        String password = "", ticket = "";
        long expires, resendAt, retryAt, ticketExpires;
        AuthFlowListener listener;
        AuthFlowState(boolean signup) {
            this.signup = signup; id = UUID.randomUUID().toString();
            expires = SystemClock.elapsedRealtime() + 30 * 60 * 1000L;
        }
        public int resendSeconds() { return seconds(resendAt); }
        public int retrySeconds() { return seconds(retryAt); }
        public int ticketSeconds() { return seconds(ticketExpires); }
        private static int seconds(long deadline) {
        return (int) Math.max(0, (deadline - SystemClock.elapsedRealtime() + 999L) / 1000L);
    }
}
