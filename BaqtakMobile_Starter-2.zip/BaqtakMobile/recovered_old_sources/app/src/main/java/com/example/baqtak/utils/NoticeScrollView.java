package com.example.baqtak.utils;

import android.content.Context;
import android.widget.ScrollView;

/** Keeps long notices readable by scrolling, including at large font scales. */
public final class NoticeScrollView extends ScrollView {
    public NoticeScrollView(Context context) { super(context); }
    @Override protected void onMeasure(int widthSpec, int heightSpec) {
        int limit = (int) (getResources().getDisplayMetrics().heightPixels * .22f);
        if (MeasureSpec.getMode(heightSpec) != MeasureSpec.UNSPECIFIED) {
            limit = Math.min(limit, MeasureSpec.getSize(heightSpec));
        }
        super.onMeasure(widthSpec, MeasureSpec.makeMeasureSpec(Math.max(1, limit), MeasureSpec.AT_MOST));
    }
}
