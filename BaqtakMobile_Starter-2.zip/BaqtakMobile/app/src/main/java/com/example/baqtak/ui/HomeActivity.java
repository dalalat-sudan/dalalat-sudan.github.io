package com.example.baqtak.ui;
import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.widget.LinearLayout;
import com.google.firebase.auth.FirebaseAuth;
public class HomeActivity extends Activity {
    @Override public void onCreate(Bundle b){super.onCreate(b);
        LinearLayout root=Ui.body(this);Ui.brand(this,root,"الرئيسية");
        boolean preview=getIntent().getBooleanExtra("preview",false);
        Ui.text(this,root,preview?"معاينة بدون تسجيل":"أهلاً بك في باقتك",24,Ui.BLUE,true,30);
        Ui.note(this,root,"هذه واجهة أولية. الأقسام والعروض الحقيقية ستُحمّل بعد ربط بيانات مشروع Supabase / Lovable الأصلي.");
        addCard(root,"خدمات الاتصالات والإنترنت","إدارة باقاتك الرقمية بسهولة");
        addCard(root,"العروض والخدمات","كل العروض في واجهة واحدة");
        addCard(root,"حسابي","إعدادات الحساب والمتابعة");
        Ui.button(this,root,preview?"الذهاب إلى تسجيل الدخول":"تسجيل الخروج",false,28,()->{
            FirebaseAuth a=AuthBridge.get(this);if(a!=null)a.signOut();
            Intent i=new Intent(this,LoginActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);startActivity(i);finish();
        });
    }
    void addCard(LinearLayout root,String title,String sub){
        LinearLayout panel=Ui.panel(this,root);Ui.text(this,panel,title,20,Ui.BLUE,true,0);Ui.note(this,panel,sub);
    }
    @Override public void onBackPressed(){super.onBackPressed();}
}
