package com.example.baqtak.ui;
import android.app.Activity;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.view.Gravity;

public class OnboardingActivity extends Activity {
    private int step=0;
    private final String[] headings={"أهلاً بك في باقتك","كل الخدمات في مكان واحد","حسابك في أمان"};
    private final String[] desc={"تجربة بسيطة وسريعة للوصول إلى خدماتك الرقمية.","استعرض التصنيفات والعروض من واجهة واحدة.","سجّل الدخول لحفظ بيانات حسابك ومتابعة طلباتك."};
    @Override public void onCreate(Bundle b){super.onCreate(b);draw();}
    private void draw(){
        LinearLayout root=Ui.body(this);Ui.brand(this,root,"تطبيق باقتك");
        Ui.text(this,root,(step+1)+" / 3",14,Ui.MUTED,false,28);
        LinearLayout card=Ui.panel(this,root);
        Ui.text(this,card,headings[step],25,Ui.BLUE,true,22);
        Ui.text(this,card,desc[step],17,Ui.TEXT,false,18);
        Ui.button(this,root,step==2?"ابدأ الآن":"التالي",true,26,()->{
            if(step<2){step++;draw();}else done();
        });
        Ui.button(this,root,"تخطي",false,12,this::done);
    }
    private void done(){getSharedPreferences("baqtak_preferences",MODE_PRIVATE).edit().putBoolean("onboarding_completed",true).apply();Ui.open(this,LoginActivity.class);finish();}
}
