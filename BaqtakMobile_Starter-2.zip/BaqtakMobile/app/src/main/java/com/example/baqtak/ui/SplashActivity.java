package com.example.baqtak.ui;
import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.content.Intent;
import android.widget.LinearLayout;
import android.widget.TextView;

public class SplashActivity extends Activity {
    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        LinearLayout page=Ui.body(this);Ui.brand(this,page,"خدماتك الرقمية في مكان واحد");
        TextView v=Ui.text(this,page,"جاري التشغيل...",16,Ui.MUTED,false,44);v.setGravity(android.view.Gravity.CENTER);
        new Handler(Looper.getMainLooper()).postDelayed(()->{
            if(isFinishing()||isDestroyed())return;
            boolean seen=getSharedPreferences("baqtak_preferences",MODE_PRIVATE).getBoolean("onboarding_completed",false);
            startActivity(new Intent(this,seen?LoginActivity.class:OnboardingActivity.class));finish();
        },1100);
    }
}
