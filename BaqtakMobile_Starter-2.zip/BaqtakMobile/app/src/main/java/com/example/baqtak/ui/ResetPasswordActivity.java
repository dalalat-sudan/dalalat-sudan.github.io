package com.example.baqtak.ui;
import android.app.Activity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Button;
import com.google.firebase.auth.FirebaseAuth;

public class ResetPasswordActivity extends Activity {
    EditText email;Button send;
    @Override public void onCreate(Bundle b){super.onCreate(b);
        LinearLayout root=Ui.body(this);Ui.brand(this,root,"استعادة كلمة المرور");
        LinearLayout p=Ui.panel(this,root);
        Ui.note(this,p,"أدخل بريدك الإلكتروني وسنرسل رابط إعادة تعيين كلمة المرور.");
        email=Ui.input(this,p,"البريد الإلكتروني",false);
        send=Ui.button(this,p,"إرسال رابط الاستعادة",true,18,this::reset);
        Ui.button(this,root,"العودة لتسجيل الدخول",false,18,()->finish());
    }
    private void reset(){String e=email.getText().toString().trim();
        if(!android.util.Patterns.EMAIL_ADDRESS.matcher(e).matches()){email.setError("بريد غير صحيح");return;}
        FirebaseAuth a=AuthBridge.require(this);if(a==null)return;
        Ui.busy(send,true,"إرسال رابط الاستعادة");
        a.sendPasswordResetEmail(e).addOnCompleteListener(this,t->{
            Ui.busy(send,false,"إرسال رابط الاستعادة");
            if(t.isSuccessful())Ui.alert(this,"تحقق من بريدك","إذا كان هذا البريد مسجلاً، فاتبع تعليمات الاستعادة الواردة فيه.");
            else Ui.alert(this,"تعذر الإرسال",t.getException()==null?"حاول مرة أخرى":t.getException().getLocalizedMessage());
        });
    }
}
