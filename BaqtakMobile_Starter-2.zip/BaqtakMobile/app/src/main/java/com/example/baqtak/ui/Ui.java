package com.example.baqtak.ui;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public final class Ui {
    private Ui() {}
    public static final int BLUE = Color.rgb(0, 57, 120);
    public static final int GRAY = Color.rgb(220, 225, 231);
    public static final int TEXT = Color.rgb(28, 45, 65);
    public static final int MUTED = Color.rgb(103, 116, 131);
    public static final int BG = Color.rgb(246, 249, 252);

    static int dp(Context c, int n) {return (int)(n*c.getResources().getDisplayMetrics().density+.5f);}
    static GradientDrawable shape(int color, int stroke, int radius, Context c) {
        GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(c,radius));
        if (stroke!=0) g.setStroke(dp(c,1),stroke);return g;
    }
    static LinearLayout.LayoutParams lp(Context c, int top) {
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(c,top);return p;
    }
    static LinearLayout body(Activity a) {
        a.getWindow().setStatusBarColor(BLUE);
        ScrollView sc = new ScrollView(a); sc.setFillViewport(true); sc.setBackgroundColor(BG);
        LinearLayout body = new LinearLayout(a);body.setOrientation(LinearLayout.VERTICAL);
        body.setGravity(Gravity.RIGHT); body.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        body.setPadding(dp(a,24),dp(a,26),dp(a,24),dp(a,35));
        sc.addView(body); a.setContentView(sc);return body;
    }
    static TextView text(Activity a, LinearLayout parent, String t, int size, int color, boolean bold, int margin) {
        TextView v=new TextView(a); v.setText(t);v.setTextColor(color);v.setTextSize(size);
        v.setGravity(Gravity.RIGHT);v.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        parent.addView(v,lp(a,margin));return v;
    }
    static void brand(Activity a,LinearLayout root, String subtitle) {
        TextView name=text(a,root,"باقتك",34,BLUE,true,8);name.setGravity(Gravity.CENTER);
        TextView sub=text(a,root,subtitle,14,MUTED,false,4);sub.setGravity(Gravity.CENTER);
    }
    static LinearLayout panel(Activity a, LinearLayout root) {
        LinearLayout p=new LinearLayout(a);p.setOrientation(LinearLayout.VERTICAL);
        p.setPadding(dp(a,20),dp(a,18),dp(a,20),dp(a,24));
        p.setBackground(shape(Color.WHITE,GRAY,20,a));root.addView(p,lp(a,24));return p;
    }
    static EditText input(Activity a,LinearLayout p,String hint, boolean password) {
        EditText e=new EditText(a);e.setSingleLine(true);e.setTextSize(16);e.setTextColor(TEXT);
        e.setHint(hint);e.setHintTextColor(MUTED);
        e.setPadding(dp(a,14),0,dp(a,14),0);
        e.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        e.setBackground(shape(Color.WHITE,GRAY,12,a));e.setMinimumHeight(dp(a,56));
        e.setInputType(password ? InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD
            : hint.contains("البريد") ? InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
            : InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        p.addView(e,lp(a,12));return e;
    }
    static Button button(Activity a,LinearLayout p,String caption,boolean primary,int margin,Runnable click) {
        Button b=new Button(a);b.setText(caption);b.setTextSize(15);b.setAllCaps(false);
        b.setTextColor(primary?Color.WHITE:BLUE);
        b.setBackground(shape(primary?BLUE:Color.WHITE, primary?0:GRAY,14,a));
        b.setMinimumHeight(dp(a,54));p.addView(b,lp(a,margin));b.setOnClickListener(v->click.run());return b;
    }
    static void note(Activity a,LinearLayout root,String caption) {text(a,root,caption,13,MUTED,false,14);}
    static void open(Activity a,Class<?> c){a.startActivity(new android.content.Intent(a,c));}
    static void alert(Activity a,String title,String message) {
        new android.app.AlertDialog.Builder(a).setTitle(title).setMessage(message)
            .setPositiveButton("حسناً",(d,w)->d.dismiss()).show();
    }
    static void busy(Button b,boolean on,String normal) {b.setEnabled(!on);b.setText(on?"جارٍ التنفيذ...":normal);}
}
