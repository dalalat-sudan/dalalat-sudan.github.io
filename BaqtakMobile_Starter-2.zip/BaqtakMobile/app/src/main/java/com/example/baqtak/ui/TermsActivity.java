package com.example.baqtak.ui;
import android.app.Activity;
import android.os.Bundle;
import android.widget.LinearLayout;
public class TermsActivity extends Activity {
    @Override public void onCreate(Bundle b){super.onCreate(b);
        LinearLayout root=Ui.body(this);Ui.brand(this,root,"الشروط والأحكام");
        LinearLayout p=Ui.panel(this,root);
        Ui.text(this,p,"نموذج مؤقت — غير صالح للنشر",20,Ui.BLUE,true,0);
        Ui.note(this,p,"يجب إدراج الشروط الرسمية المعتمدة لتطبيق باقتك قبل إطلاق التطبيق أو السماح بالتسجيل الحقيقي للمستخدمين. لا يُعد النص الحالي سياسة قانونية.");
        Ui.button(this,root,"رجوع",false,14,()->finish());
    }
}
