package com.example.baqtak.ui;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.GoogleAuthProvider;

public class LoginActivity extends Activity {
    private static final int GOOGLE_REQUEST=2026;
    private EditText email,password;
    private Button submit,google;
    private boolean processing;
    @Override public void onCreate(Bundle b){super.onCreate(b);draw();}
    private void draw(){
        LinearLayout root=Ui.body(this);Ui.brand(this,root,"تسجيل الدخول إلى حسابك");
        LinearLayout panel=Ui.panel(this,root);
        Ui.text(this,panel,"مرحباً بعودتك",23,Ui.BLUE,true,0);
        Ui.note(this,panel,"أدخل بريد حسابك وكلمة المرور الخاصة بالتطبيق.");
        email=Ui.input(this,panel,"البريد الإلكتروني",false);
        password=Ui.input(this,panel,"كلمة المرور",true);
        submit=Ui.button(this,panel,"تسجيل الدخول",true,20,this::login);
        google=Ui.button(this,panel,"المتابعة باستخدام Google",false,12,this::startGoogle);
        Ui.button(this,panel,"نسيت كلمة المرور؟",false,12,()->Ui.open(this,ResetPasswordActivity.class));
        Ui.button(this,root,"إنشاء حساب جديد",false,18,()->Ui.open(this,RegisterActivity.class));
        Ui.note(this,root,"هذه نسخة معاينة. حسابات موقع باقتك الأصلي على Supabase لا تنتقل تلقائياً إلى Firebase.");
        Ui.button(this,root,"معاينة الواجهة الرئيسية بدون تسجيل",false,16,()->{
            Intent i=new Intent(this,HomeActivity.class);i.putExtra("preview",true);startActivity(i);
        });
    }
    private void login(){
        if(processing)return;
        String e=email.getText().toString().trim(),p=password.getText().toString();
        if(!android.util.Patterns.EMAIL_ADDRESS.matcher(e).matches()){email.setError("أدخل بريداً إلكترونياً صحيحاً");return;}
        if(p.isEmpty()){password.setError("أدخل كلمة المرور");return;}
        FirebaseAuth auth=AuthBridge.require(this);if(auth==null)return;
        processing=true;Ui.busy(submit,true,"تسجيل الدخول");
        auth.signInWithEmailAndPassword(e,p).addOnCompleteListener(this,t->{
            processing=false;Ui.busy(submit,false,"تسجيل الدخول");
            if(t.isSuccessful()&&auth.getCurrentUser()!=null){goHome();}
            else Ui.alert(this,"تعذر الدخول",t.getException()==null?"تحقق من البيانات والاتصال":t.getException().getLocalizedMessage());
        });
    }
    private void startGoogle(){
        if(AuthBridge.require(this)==null)return;
        int res=getResources().getIdentifier("default_web_client_id","string",getPackageName());
        if(res==0){Ui.alert(this,"إعداد Google ناقص","تحقق من ملف google-services.json وبصمة SHA-1 وإعداد مزود Google في Firebase.");return;}
        String id=getString(res);
        GoogleSignInOptions opts=new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(id).requestEmail().build();
        startActivityForResult(GoogleSignIn.getClient(this,opts).getSignInIntent(),GOOGLE_REQUEST);
    }
    @Override protected void onActivityResult(int req,int result,Intent data){
        super.onActivityResult(req,result,data);
        if(req!=GOOGLE_REQUEST)return;
        try {
            Task<GoogleSignInAccount> t=GoogleSignIn.getSignedInAccountFromIntent(data);
            GoogleSignInAccount acct=t.getResult(ApiException.class);
            if(acct==null||acct.getIdToken()==null)throw new IllegalStateException("Google ID token missing");
            FirebaseAuth auth=AuthBridge.require(this);if(auth==null)return;
            auth.signInWithCredential(GoogleAuthProvider.getCredential(acct.getIdToken(),null))
                .addOnCompleteListener(this,resultTask->{
                    if(resultTask.isSuccessful())goHome();
                    else Ui.alert(this,"تعذر تسجيل Google",resultTask.getException()==null?"حاول مجدداً":resultTask.getException().getLocalizedMessage());
                });
        }catch(Exception e){Ui.alert(this,"تعذر تسجيل Google","تأكد من إعداد Google وSHA-1، ثم حاول مجدداً. التفاصيل: "+e.getMessage());}
    }
    private void goHome(){Intent i=new Intent(this,HomeActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);startActivity(i);finish();}
}
