package com.example.baqtak.ui;
import android.app.Activity;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;

/** Preview is usable before the user registers their correct Firebase Android app. */
public final class AuthBridge {
    private AuthBridge() {}
    public static FirebaseAuth get(Activity a) {
        try {
            FirebaseApp app=FirebaseApp.initializeApp(a);
            if (app==null) return null;
            return FirebaseAuth.getInstance(app);
        } catch (Exception e) {return null;}
    }
    public static FirebaseAuth require(Activity a) {
        FirebaseAuth auth=get(a);
        if(auth==null) Ui.alert(a,"Firebase غير مرتبط", "نسخة المعاينة تعمل، لكن يلزم تنزيل ملف google-services.json الصحيح ووضعه داخل مجلد app، ثم إعادة بناء التطبيق. لا تستخدم مشروع Firebase غير المخصص لباقتك.");
        return auth;
    }
}
