package com.example.baqtak.ui;
import android.app.Activity;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.content.Intent;
import com.google.firebase.auth.FirebaseAuth;

public class RegisterActivity extends Activity {
    EditText first,second,family,email,pass,confirm;
    CheckBox accept;Button submit;
    @Override public void onCreate(Bundle b){super.onCreate(b);draw();}
    private void draw(){
        LinearLayout root=Ui.body(this);Ui.brand(this,root,"إنشاء حساب جديد");
        LinearLayout panel=Ui.panel(this,root);
        first=Ui.input(this,panel,"الاسم الأول",false);
        second=Ui.input(this,panel,"الاسم الثاني",false);
        family=Ui.input(this,panel,"اسم العائلة",false);
        email=Ui.input(this,panel,"البريد الإلكتروني",false);
        pass=Ui.input(this,panel,"كلمة المرور",true);
        confirm=Ui.input(this,panel,"تأكيد كلمة المرور",true);
        accept=new CheckBox(this);accept.setText("أوافق على الشروط والأحكام");accept.setTextColor(Ui.TEXT);panel.addView(accept,Ui.lp(this,12));
        Ui.button(this,panel,"قراءة الشروط والأحكام",false,8,()->Ui.open(this,TermsActivity.class));
        submit=Ui.button(this,panel,"إنشاء الحساب",true,18,this::register);
        Ui.button(this,root,"لدي حساب بالفعل — تسجيل الدخول",false,18,()->finish());
    }
    private void register(){
        String e=email.getText().toString().trim(),p=pass.getText().toString();
        if(TextUtils.isEmpty(first.getText().toString().trim())||TextUtils.isEmpty(second.getText().toString().trim())||TextUtils.isEmpty(family.getText().toString().trim())){Ui.alert(this,"بيانات ناقصة","أكمل الاسم الأول والثاني والعائلة.");return;}
        if(!android.util.Patterns.EMAIL_ADDRESS.matcher(e).matches()){email.setError("بريد غير صحيح");return;}
        if(p.length()<6){pass.setError("استخدم 6 أحرف على الأقل");return;}
        if(!p.equals(confirm.getText().toString())){confirm.setError("كلمتا المرور غير متطابقتين");return;}
        if(!accept.isChecked()){Ui.alert(this,"الشروط والأحكام","يجب الموافقة قبل التسجيل.");return;}
        FirebaseAuth auth=AuthBridge.require(this);if(auth==null)return;
        Ui.busy(submit,true,"إنشاء الحساب");
        auth.createUserWithEmailAndPassword(e,p).addOnCompleteListener(this,t->{
            Ui.busy(submit,false,"إنشاء الحساب");
            if(t.isSuccessful()&&auth.getCurrentUser()!=null){
                auth.getCurrentUser().sendEmailVerification().addOnCompleteListener(this,s->{
                    Intent i=new Intent(this,VerifyOtpActivity.class);i.putExtra("email",e);startActivity(i);finish();
                });
            }else Ui.alert(this,"تعذر إنشاء الحساب",t.getException()==null?"حاول مرة أخرى":t.getException().getLocalizedMessage());
        });
    }
}
