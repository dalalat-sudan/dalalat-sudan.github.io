package com.example.baqtak.ui;
import android.app.Activity;
import android.os.Bundle;
import android.widget.LinearLayout;
import com.google.firebase.auth.FirebaseAuth;

/** In Firebase Email/Password mode, email verification uses a link, NOT the old Supabase six-digit OTP flow. */
public class VerifyOtpActivity extends Activity {
    @Override public void onCreate(Bundle b){super.onCreate(b);
        LinearLayout root=Ui.body(this);Ui.brand(this,root,"تأكيد البريد الإلكتروني");
        LinearLayout panel=Ui.panel(this,root);
        Ui.text(this,panel,"افتح بريدك الإلكتروني",22,Ui.BLUE,true,0);
        Ui.note(this,panel,"تم طلب رسالة تحقق. افتح رابط التحقق في الرسالة ثم عد للتطبيق. هذا ليس رمز OTP المكون من 6 أرقام في نظام الموقع السابق.");
        String e=getIntent().getStringExtra("email");if(e!=null)Ui.note(this,panel,e);
        Ui.button(this,panel,"تحقق من حالة الحساب",true,22,()->{
            FirebaseAuth auth=AuthBridge.require(this);if(auth==null||auth.getCurrentUser()==null)return;
            auth.getCurrentUser().reload().addOnCompleteListener(this,t->{
                if(t.isSuccessful()&&auth.getCurrentUser()!=null&&auth.getCurrentUser().isEmailVerified()){
                    Ui.open(this,HomeActivity.class);finish();
                }else Ui.alert(this,"لم يكتمل التحقق","افتح رابط التحقق داخل البريد ثم أعد المحاولة.");
            });
        });
        Ui.button(this,root,"العودة لتسجيل الدخول",false,12,()->{Ui.open(this,LoginActivity.class);finish();});
    }
}
